﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSException
{
    /// <summary>
    /// Exception Class to work on Exception Hnadelling
    /// Author : Lalith Amudala - 158050
    /// DOC: 28/08/2018
    /// </summary>
    public class PassengerException : ApplicationException
    {
        public PassengerException() : base() { }

        public PassengerException(string Message) : base(Message) { }
    }
}
