﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using TRSEntities;
using TRSException;
using System.IO;

namespace TRSDAL
{
    public class PassengerDAL
    {
        static List<Passengerdetails> PassengerList = new List<Passengerdetails>();

        public bool AddPassenger(Passengerdetails newPassengerList)
        {
            bool isAddedPassenger = false;
            try
            {
                PassengerList.Add(newPassengerList);
                SerializePassenger();
                isAddedPassenger = true;
            }
            catch (PassengerException)
            {
                throw;
            }
            return isAddedPassenger;
        }

        public List<Passengerdetails> DisplayPassengerList()
        {

            return DeserializePassenger();
        }
        /// <summary>
        /// serealization Procesas 
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        public static void SerializePassenger()
        {
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("PassengerList.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter Formatter = new BinaryFormatter();
                Formatter.Serialize(fStream, PassengerList);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
        }

        /// <summary>
        /// deserealization Procesas 
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>

        public static List<Passengerdetails> DeserializePassenger()
        {
            List<Passengerdetails> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("PassengerList.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializedData = (List<Passengerdetails>)Formatter.Deserialize(fStream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
            return deserializedData;
        }

        public Passengerdetails SearchPassengerDAL(int PNR_No)
        {
            Passengerdetails searchPassenger;
            try
            {
                searchPassenger = PassengerList.Find(passenger => passenger.PNR_No == PNR_No);
            }
            catch (PassengerException) { throw; }
            return searchPassenger;
        }
    }
}
