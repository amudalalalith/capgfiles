﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSBLL;
using TRSEntities;
using TRSException;
namespace TRSPL
{
    /// <summary>
    /// Console Application to ADD, View PASSENGER DETAILS to the BLL AND also Included SErialization and DE serializaytion
    /// Author : Lalith Amudala - 158050
    /// DOC: 28/08/2018
    /// </summary>
    class TRSMain

    {
        /// <summary>
        /// Adding Passenger Details to BLL
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        public static void AddPassengerPL()
        {
            try
            {
                Passengerdetails objPassenger = new Passengerdetails();
                Console.WriteLine("Enter PNR No :");
                bool chckPnr;
                int Pid;
                chckPnr = Int32.TryParse(Console.ReadLine(), out Pid);
                if (chckPnr == false)
                {
                    throw new PassengerException("Invalid Entry");
                }
                else
                {
                    objPassenger.PNR_No = Pid;
                }
                Console.WriteLine("Enter Source: ");
                objPassenger.Source = Console.ReadLine();
                Console.WriteLine("Enter Destination : ");
                objPassenger.Destination = Console.ReadLine();
                //Console.WriteLine("Enyter Date");
                //objPassenger.DateOfJorney = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Type");
                string typeofSeat = Console.ReadLine();

                switch (typeofSeat)
                {
                    case "SLEEPER":
                        objPassenger.ClassType = "SLEEPER";
                        break;

                    case "3AC":
                        objPassenger.ClassType = "3AC";
                        break;

                    case "2AC":
                        objPassenger.ClassType = "2AC";
                        break;

                    case "1AC":
                        objPassenger.ClassType = "1AC";
                        break;

                    default:
                        objPassenger.ClassType = "SLEEPER";
                        break;
                }

                Console.WriteLine("Enter No of Passengers");
                objPassenger.NoOfTickets = int.Parse(Console.ReadLine());

                PassengerBLL bllObj = new PassengerBLL();
                if (bllObj.AddPassangerBLL(objPassenger) == false)
                { throw new PassengerException("Passenger Details could not be added"); }
                else
                {
                    Console.WriteLine("Student Details Added Succesfully");
                }

            }
            catch (PassengerException Exception)
            {
                Console.WriteLine("Error Occured" + Exception.Message);
            }
        }
        /// <summary>
        /// Displaying Passenger Details
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        public static void DisplayPassengerPL()
        {
            try
            {
                PassengerBLL bllobj = new PassengerBLL();
                List<Passengerdetails> pList = new List<Passengerdetails>();
                pList = bllobj.DisplayPassengerBL();
                Console.WriteLine("Student Details");
                Console.WriteLine("=================");
                foreach (Passengerdetails p in pList)
                {
                    Console.WriteLine("PNR No : {0}\n Source : {1}\n Destination : {2}\n Date Of journey : {3}\n Type : {4}\n No Of Tickets : {4} ", p.PNR_No, p.Source, p.Destination, p.DateOfJorney, p.ClassType, p.NoOfTickets);
                }

            }
            catch (PassengerException p)
            {
                Console.WriteLine(p.Message);
            }
        }
        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice");
                bool chkChoise;

                chkChoise = byte.TryParse(Console.ReadLine(), out choice);
                if (!chkChoise)
                {
                    Console.WriteLine("Invalid input");
                }
                switch (choice)
                {
                    case 1:
                        AddPassengerPL();
                        break;
                    case 2:
                        DisplayPassengerPL();
                        break;
                    case 3:
                        SearchpassengerPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choise:");
                        break;

                }

            } while (choice != 0);
        }

        /// <summary>
        /// Searching Passenger Details
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        private static void SearchpassengerPL()
        {
            Passengerdetails searchpassenger = null;
            try
            {
                Console.WriteLine("Enyter PNR no to search:");
                int PNR_No = Int32.Parse(Console.ReadLine());
                PassengerBLL passengerBLL = new PassengerBLL();

                searchpassenger = passengerBLL.SearchPassengerBLL(PNR_No);
                if (searchpassenger != null)
                {
                    Console.WriteLine("Searched Passenhger:");
                    Console.WriteLine("PNR No: {0}", searchpassenger.PNR_No);
                    Console.WriteLine("Source: {0}", searchpassenger.Source);
                    Console.WriteLine("Destination: {0}", searchpassenger.Destination);
                }
            }
            catch (PassengerException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("============================================");
            Console.WriteLine("Ticket Reservation System");
            Console.WriteLine("Press 1 To Add New Student");
            Console.WriteLine("Press 2 To Display All Students");
            Console.WriteLine("Press 3 To Search Student");
            Console.WriteLine("Press 0 To Exit");
            Console.WriteLine("============================================");

        }
    }
}
