﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSDAL;
using TRSEntities;
using TRSException;
namespace TRSBLL
{
    /// <summary>
    /// Console Application to ADD, View PASSENGER DETAILS to the DAL AND also Included SErialization and DE serializaytion
    /// Author : Lalith Amudala - 158050
    /// DOC: 28/08/2018
    /// </summary>
    public class PassengerBLL
    {
        static List<Passengerdetails> PassList = new List<Passengerdetails>();
        /// <summary>
        /// Adding Passenger Details to DAL
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        public bool AddPassangerBLL(Passengerdetails Passenger)
        {
            PassengerDAL PassengerOperations = new PassengerDAL();
            bool isAdded;
            try
            {
                if (ValidatePassenger(Passenger))
                {
                    isAdded = PassengerOperations.AddPassenger(Passenger);
                }
                else
                {
                    throw new PassengerException("Validation Failed! ");
                }
                if (isAdded == false)
                {
                    throw new PassengerException("Student Details Not Valid");
                }
            }
            catch
            {

            }
            return true;
        }
        /// <summary>
        /// Display Passenger Details to DAL
        /// Author : Lalith Amudala - 158050
        /// DOC: 28/08/2018
        /// </summary>
        public List<Passengerdetails> DisplayPassengerBL()
        {
            PassengerDAL PassengerOperations = new PassengerDAL();
            try
            {
                PassList = PassengerOperations.DisplayPassengerList();
                if (PassList.Count <= 0)
                {
                    throw new PassengerException("No records Found!!!");
                }
            }
            catch (PassengerException p)
            {
                throw p;
            }
            return PassList;
        }
        public static bool ValidatePassenger(Passengerdetails Passenger)
        {
            bool ValidPassenger = true;
            StringBuilder message = new StringBuilder();
            if (!((Passenger.PNR_No != 0) && (Passenger.Source != null) && (Passenger.Destination != null) && (Passenger.Destination != null) && (Passenger.ClassType != null)))
            {
                message.Append(Environment.NewLine + "Invalid Passenger Details");
                ValidPassenger = false;

            }
            int val = (Passenger.PNR_No) / 100000;
            if (!(val == 8))
            {
                message.Append(Environment.NewLine + "Invalid PNR Number");
                ValidPassenger = false;
            }
            //(Passenger.ClassType == "Sleeper") || (Passenger.ClassType == "3AC") || (Passenger.ClassType == "2AC") ||  ( Passenger.ClassType == "1AC") 
            //if(!)
            //{

            //    ValidPassenger = false;
            //}
            if (ValidPassenger == false)
            {
                throw new PassengerException(message.ToString());
            }
            return ValidPassenger;

        }

        public Passengerdetails SearchPassengerBLL(int PNR_No)
        {
            Passengerdetails searchPassenger = null;
            try
            {
                PassengerDAL passengerDal = new PassengerDAL();
                searchPassenger = passengerDal.SearchPassengerDAL(PNR_No);
            }
            catch (PassengerException px) { throw px; }
            return searchPassenger;
        }


    }
}