﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    /// <summary>
    /// To Create a Base class for performing  salary operations easy based on Employee Type
    /// Author: CG
    /// DOC: 28/8/2018
    /// </summary>
    public class Employee
    {
        public string EmployeeName { get; set; }
        public int EmployeeId { get; set; }
        public string Employeetype { get; set; }

        //Mentioned as virtual to make it overridable
        public virtual double GetSalary(double salary)
        {
            return salary;
        }
    }
}
