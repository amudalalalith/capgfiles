﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    /// <summary>
    /// To Inherit From Base class to perform OCP 
    /// Author: CG
    /// DOC: 28/8/2018
    /// </summary>
    class ContractEmployee : Employee
    {
        Employee em = new Employee();

        //overriding Base Class Function
        public override double GetSalary(double salary)
        {
            salary = salary + 1000;
            return salary;
        }
    }

}
