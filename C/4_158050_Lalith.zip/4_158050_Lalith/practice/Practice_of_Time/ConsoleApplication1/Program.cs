﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now.ToString("MM/dd/yyyy"));
            Console.WriteLine(DateTime.Now.ToString("MM"));

            DateTime datetime = new DateTime();
            datetime.GetDateTimeFormats();
        }
    }
}
