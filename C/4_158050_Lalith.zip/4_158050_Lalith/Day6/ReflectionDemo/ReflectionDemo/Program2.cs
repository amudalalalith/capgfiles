﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Employee
    {
        public int id;
        public string name;
        public float salary;

        public Employee() { }
        public Employee(int id, string name, float salary) { }

        public void SetEmployee() { }
        public void GetEmployee() { }

        public int TotalExperience { get; set; }
        public int CurrentExperience { get; set; }
    }
    class Program2
    {
        static void Main(string[] args)
        {
            Type empType = typeof(Employee);

            MethodInfo[] methods = empType.GetMethods();
            foreach(MemberInfo method in methods)
            {
                Console.WriteLine(method.Name);
            }
            Console.WriteLine();

            ConstructorInfo[] constroctors = empType.GetConstructors();
            foreach(ConstructorInfo m in constroctors)
            {
                Console.WriteLine(m.Name);
            }
        }
    }
}
