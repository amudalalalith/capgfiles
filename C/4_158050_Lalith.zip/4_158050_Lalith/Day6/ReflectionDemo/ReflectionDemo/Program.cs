﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFrom(@"D:\Project 1\Day5\SMS\SMSBLL\bin\Debug\SMSBLL.dll");
            Type[] types = assembly.GetTypes();

            foreach(Type type in types)
            {
                Console.WriteLine(type.Name+"--"+type.FullName + "--" + type.BaseType);
            }
        }
    }
}
