﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesDemo
{
    public delegate int MathDelegate(int x, int y);
    class Program4
    {
       
        static void Main(string[] args)
        {
            //MathDelegate mathDelegate = delegate (int x, int y)
            //{
            //    return x + y;
            //};

            MathDelegate mathDelegate = (x,y) => { return x + y; };
            

            int sum = mathDelegate(10, 20);
            Console.WriteLine("Sum = "+sum);
            

        }
    }
}
