﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesDemo
{
    //Create the Delegate
    public delegate void MyDelegate();

    class Program
    {
    //delegate method declaration
    public static void Display()
    {
        Console.WriteLine("Inside Display()");
    }
    public static void Show()
    {
        Console.WriteLine("Inside Show()");
    }
    static void Main(string[] args)
        {
            MyDelegate obj1 = new MyDelegate(Display);
            MyDelegate obj2 = new MyDelegate(Show);


            obj1();
            obj2();

        }
    }
}
