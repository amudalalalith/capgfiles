﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesDemo
{
    public delegate T MyGenericDelegate<T>(T x, T y);
    class Program2
    {
        public static int Sum(int x, int y)
        {
            return x + y;
        }

        public static double Divide(double x, double y)
        {
            return x / y;
        }
        static void Main(string[] args)
        {
            MyGenericDelegate<int> del1 = new
                 MyGenericDelegate<int>(Sum);

            MyGenericDelegate<double> del2 = new
                 MyGenericDelegate<double>(Divide);

            Console.WriteLine("Result 1 = "+del1(10, 8));
            Console.WriteLine("Result 2 = " + del2(88.77, 11.2));
        }
    }
}
