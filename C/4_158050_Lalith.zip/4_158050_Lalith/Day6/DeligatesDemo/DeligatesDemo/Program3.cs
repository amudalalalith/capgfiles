﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesDemo
{
    public delegate void MyOperation(double x, double y);
    class Program3
    {
        static void Summation(double x, double y)
        {
            Console.WriteLine("Sum = " + (x + y));
        }

        static void Difference(double x, double y)
        {
            Console.WriteLine("Difference = " + (x - y));
        }
        static void Multiply(double x, double y)
        {
            Console.WriteLine("Product = " + (x * y));
        }

        static void Divide(double x, double y)
        {
            Console.WriteLine("Quotient = " + (x / y));
        }
        static void Main(string[] args)
        {

            MyOperation obj = new MyOperation(Summation);
            //obj += new MyDelegates(Sum);
            obj += new MyOperation(Difference);
            obj += new MyOperation(Multiply);
            obj += new MyOperation(Divide);
            obj(10, 20);
        }
    }
}
