﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    class MultiDimensionalArrayDemo
    {
        static void Main(string[] args)
        {
            string[,] Students = new string[,]
            {
                { "Manish","Rajhan"},
                {"Lalith" , "Amudala" },
                {"Debanjan","Das" }
            };

            for (int i = 0; i <Students.GetLength(0); i++)
            {
                for (int j= 0; j< Students.GetLength(1);j++)
                {
                    Console.Write(Students[i, j] + "\t");
                    
                }
                Console.WriteLine();
            }
        }
    }
}
