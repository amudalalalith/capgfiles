﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    public class Employee
    {
        private int EmployeeId;
        private string Employeename;
        private double Salary;

        public void setEmployee(int EmployeeId, string Employeename, double Salary )
        {
            this.EmployeeId = EmployeeId;
            this.Employeename = Employeename;
            this.Salary = Salary;
        }

        public void getEmployee()
        {
            Console.WriteLine("Employee ID: {0}, Employee Name :  {1}, Salary : {2}" ,EmployeeId,Employeename,Salary);
            

        }

    }
}
