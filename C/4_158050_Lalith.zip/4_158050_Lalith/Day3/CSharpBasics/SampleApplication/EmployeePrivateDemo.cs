﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    class EmployeePrivateDemo
    {
        static void Main(string[] args)
        {
            Employee Employee1 = new Employee();
            Employee1.setEmployee(101, "Lali", 20000);
            Employee1.getEmployee();
        }
    }
}
