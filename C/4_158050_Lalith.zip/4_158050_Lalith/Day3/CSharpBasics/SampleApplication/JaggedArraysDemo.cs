﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    class JaggedArraysDemo
    {
        static void Main(string[] args)
        {
            string[][] ItTParks = new string[3][];
            ItTParks[0] = new string[3] { "SIPCOT", "TIDELPark ", "MIPL" };
            ItTParks[1] = new string[4] { "SEEP2", "IK2", "MIL", "lakal " };
            ItTParks[2] = new string[3] { "COT", "TIPark ", "IPL" };

            for (int i = 0; i < ItTParks.GetLength(0); i++)
            {
                for (int j = 0; j < ItTParks[i].GetLength(0); j++)
                {
                    Console.Write(ItTParks[i][j] + "\t");

                }
                Console.WriteLine();
            }

        }
    }
}
