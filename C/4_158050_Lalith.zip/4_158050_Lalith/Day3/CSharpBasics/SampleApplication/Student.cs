﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    struct Student
    {
        int Roll_Number;
        string Name;
        string Division;

      public void GetStudents()
        {
            Console.WriteLine("Roll No : {0}, Name : {1}, Division : {2}", Roll_Number, Name, Division);
        }

        public void SetStudents(int Roll_Number, string Name, string Division)
        {
            this.Roll_Number = Roll_Number;
            this.Name = Name;
            this.Division = Division;
        }
    }
}
