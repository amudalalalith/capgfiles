﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception_Layer;
namespace CalculatorMain
{
    class TemperatureControlDevice
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Temperatue in Degree Celcius");
            double Temperature = int.Parse(Console.ReadLine());
            try
            {
                if (Temperature <= 18 || Temperature >= 28)
                {
                    throw new TemperatureException("Temperature is Inappropriate");
                }
                else
                {
                    Console.WriteLine("I am Operating fine");
                }
            }
            catch(TemperatureException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
        }
    }
}
