﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception_Layer;
namespace CalculatorMain
{
    class Program
    {
        static void Main(string[] args)
        {
            int Number1 = 10;
            int Number2 = 0;


            Console.WriteLine(new Calculator().Add(Number1,Number2));

            try
            {
                Console.WriteLine(new Calculator().Divide(Number1, Number2));
            }
            catch (DivideByZeroException Exception)
            {
                Console.WriteLine("Exception Occured: " + Exception.Message + " Please dont divide by Zero");
            }
            catch (Exception Exception)
            {
                Console.WriteLine("Exception Occured: " + Exception.Message);
            }
            



        }
    }
}
