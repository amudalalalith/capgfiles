﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Employee_Process;

namespace Employee_Main
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select Employee Type");
            Console.WriteLine("1. Contract Employee");
            Console.WriteLine("2. Permanent Employee");
            int Choice = int.Parse(Console.ReadLine());
            switch(Choice)
            {
                case 1:
                    ContractEmployee ContractEmployee1 = new ContractEmployee();
                    Console.WriteLine("Enter Employee ID:");
                    int EmployeeId = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Employee Name:");
                    string EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter Hourly Wage:");
                    double Hourly_Wage = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Employee Hours WOrked:");
                    double No_ofDaysWorked = double.Parse(Console.ReadLine());
                    ContractEmployee1.SetDetails(EmployeeId, EmployeeName, Hourly_Wage, No_ofDaysWorked);
                    ContractEmployee1.CalculateSalary();
                    ContractEmployee1.GetDetails();
                    break;

                case 2:
                    PermanentEmployee Permanent_Employee1 = new PermanentEmployee();
                    Console.WriteLine("Enter Employee ID:");
                    EmployeeId = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Employee Name:");
                    EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter Basic Salary:");
                    double Basic_Salary = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Employee Hours WOrked:");
                    double Hra = double.Parse(Console.ReadLine());
                    Permanent_Employee1.SetDetails(EmployeeId, EmployeeName, Basic_Salary, Hra);
                    Permanent_Employee1.CalculateSalary();
                    Permanent_Employee1.GetDetails();
                    break;
            }
    

        }
    }
}
