﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Process
{
    public class ContractEmployee : IEmployee
    {
        int Id;
        string Name;
        double Hourly_Wage;
        double No_ofDaysWorked;


        public void SetDetails(int Id, string Name, double Hourly_Wage, double No_ofDaysWorked)
        {
            this.Id = Id;
            this.Name = Name;
            this.Hourly_Wage = Hourly_Wage;
            this.No_ofDaysWorked = No_ofDaysWorked;
        }

        

        public double CalculateSalary()
        {
            return Hourly_Wage * No_ofDaysWorked;
        }

        public void GetDetails()
        {
            Console.WriteLine("---------------------Employee Management System------------------");
            Console.WriteLine("Id: "+this.Id);
            Console.WriteLine("Name: "+this.Name);
            Console.WriteLine("Hourly Wage: "+this.Hourly_Wage);
            Console.WriteLine("No of Days Worked: "+this.No_ofDaysWorked);
            Console.WriteLine("Salary: "+CalculateSalary());
            Console.WriteLine("-----------------------------------------------------------------");
        }
    }
}
