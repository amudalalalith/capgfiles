﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExceptionLayer;

namespace MainImplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 ClassObject = new Class1();
            Console.WriteLine("Enter Details");
            try
            {
                ClassObject.Insert();
            }
            catch(Exception Exception)
            {
                Console.WriteLine("Exception occuyred" + Exception.Message);
            }
        }
    }
}
