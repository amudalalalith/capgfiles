﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class Class1
    {
        int[] Array1 = new int[10];
        public void Insert()
        {
            for (int i = 0; i <= 10; i++)
            {
                Array1[i] = int.Parse(Console.ReadLine());

            }
        }
    }
}
