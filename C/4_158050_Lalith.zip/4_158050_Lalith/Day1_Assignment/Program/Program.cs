﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentLibrary;
namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student();
            student1.AddStudent();
            student1.ViewStudent();

            Student student2 = new Student();
            student2.AddStudent();
            student2.ViewStudent();
        }
    }
}
