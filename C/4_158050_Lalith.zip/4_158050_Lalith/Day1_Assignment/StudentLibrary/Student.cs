﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentLibrary
{
    public class Student
    {
        public int RollNo;
        public string Name;
        public string Div;

        public static int Counter;

        //public void AddStudent(string Nam, string Division)
        public void AddStudent()
        {
            RollNo = ++Counter;
            Console.WriteLine("Enter Name: ");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Div: ");
            Div = Console.ReadLine();
        }
        public void ViewStudent()
        {
            Console.WriteLine("Roll No : {0}", RollNo);
            Console.WriteLine("Name is : {0}", Name);
            Console.WriteLine("Div is : {0}",Div);
        }
    }
}
