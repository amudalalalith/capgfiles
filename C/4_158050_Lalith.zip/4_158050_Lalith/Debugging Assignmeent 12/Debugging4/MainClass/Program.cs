﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileClass;

namespace MainClass
{
    class Program
    {

        static FileHelper fileHelperObj = null;

        static Program()
        {
            fileHelperObj = new FileHelper();
        }

        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter File Content.");
                            string data = Console.ReadLine();
                            fileHelperObj.WriteFile(@"D:\Project 1\Day5\Serilization_Deserilization\Serilization_Deserilization\bin\Debug\Student.txt",data);
                            break;
                        case 2:
                            Console.WriteLine("Enter File Path");
                            ReadFile(Console.ReadLine());
                            break;
                        case 3:
                            Console.WriteLine
                                ("Word Count: {0}\n",fileHelperObj.NoOfWordsInFile());
                            break;
                        case 4:
                            Environment.Exit(0);
                            break;
                        default:
                            break;
                    }
                } while (choice != 4);
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ReadFile(string filePath)
        {
            fileHelperObj.ReadFile(filePath);
        }

        static void PrintMenu()
        {
            Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}\n\n{5}",
                    "Welcome to File Debugging ",
                    "1. Create a new File", "2. Read a existing File",
                    "3. Return the no of words in the file which was read.\n" +
                    "Note: For this to work, you have to Read File using Option 2",
                    "4. Exit the Application.",
                    "Enter your choice");

        }

        static void WriteFile(string content)
        {
            if (fileHelperObj.WriteFile
                (@"Files\MyFile.txt", content))
            {
                Console.WriteLine("File Created.....\n");
            }
        }
    }

}
