﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileClass
{
    public class FileHelper
    {
        string fileContent = null;
        StreamWriter sw = null;
            StreamReader sr = null;

        public FileHelper()
        {

        }

        public bool WriteFile(string filePath, string fileContent)
        {
            sw.WriteLine(fileContent);
            sw.Close();
            return true;
        }

        public void ReadFile(string filePath)
        {
            fileContent = sr.ReadToEnd();
            sr.Close();
            Console.WriteLine("File content:\n{0}\n\n", fileContent);
        }

        public int NoOfWordsInFile()
        {
            string[] words = fileContent.Split(' ');
            return words.Length;
        }
    }


}
