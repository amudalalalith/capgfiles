﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public abstract class BankAccount : IBankAccount
    {
        int AccountNumber;
        string AccountHolderName;
        double Balance;
        static string Branch;
        static string IFSC;

        //Static Counter used to initialize Account Number
        static int AccountNumberCounter;

        //initializing static members(not going to change ) likr branch and IFSC
        static BankAccount()
        {
            Branch = "Chennai- SIPCOT";
            IFSC = "ICICSIPCOT001";
        }

        //Inoitialize members
        public BankAccount(string AccountHolderName, double Balance)
        {
            this.AccountNumber = ++AccountNumberCounter;
            this.AccountHolderName = AccountHolderName;
            this.Balance = Balance;
        }
        public double setBalance(double Balance)
        {
            this.Balance = Balance;
            return this.Balance;
        }
        public double ShowBalance()
        {
            return this.Balance;
        }

        //Deposit
        public abstract double Deposit(double Amount);


        //withdraw
        public abstract double Withdraw(double Amount);
        

    }
}
