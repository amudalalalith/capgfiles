﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public class CurrentAccount // : BankAccount
    {
        string AccountType;
        double OverDraftLimit;
        double Balance;
        
        public CurrentAccount(string AccountHolderName, double Balance,
             string AccountType, double OverDraftLimit)// : base(AccountHolderName, Balance)
        {
            this.AccountType = AccountType;
            this.OverDraftLimit = OverDraftLimit;
        }
        //public double Deposit(double Amount)
        //{
        //    //this.Balance = base.Showbalance();
        //    //if(this.OverDraftLimit<20000)
        //    //{
        //    //    Amount = OverDraftLimit + Amount;
        //    //    this.Balance += Amount - 20000;
        //    //    OverDraftLimit = 20000;
        //    //}
        //    return base.Deposit(this.Balance);
        //}

        //public double Withdraw(double Amount)
        //{
        //    this.Balance = base.ShowBalance();
        //    if (Amount < this.Balance)
        //    {
        //        this.Balance = Amount;
        //    }
        //    else if (Amount < (this.Balance + this.OverDraftLimit))
        //    {
        //        Amount = Amount - this.Balance;
        //        this.OverDraftLimit = this.OverDraftLimit - Amount;
        //    }
        //  return base.Withdraw(this.Balance);
        //}
        public double ShowOverdraftLimit()
        {
            return this.OverDraftLimit;
        }
    }
}
