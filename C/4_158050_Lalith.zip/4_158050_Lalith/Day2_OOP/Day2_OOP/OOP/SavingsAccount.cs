﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public class SavingsAccount : BankAccount
    {
        string AccountType;
        double IntrestRate;

        public SavingsAccount(string AccountHolderName, double Balance,
            string AccountType, double IntrestRate) : base(AccountHolderName, Balance)
        {
            this.AccountType = AccountType;
            this.IntrestRate = IntrestRate;
        }

        public override double Deposit(double Amount)
        {
            return base.setBalance(base.ShowBalance() + Amount);
        }

        public override double Withdraw(double Amount)
        {
            return base.setBalance(base.ShowBalance() - Amount);
        }

    }
}
