﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public class Employee
    {
        int EmployeeID;
        string EmployeeName;
        static string DepartmentName;
        //public Employee()
        //{
        //    EmployeeID = 101;
        //    EmployeeName = "lalith";
        //}

            //Parameterized Constructor to accept user input

        public Employee(int EmployeeID, string EmployeeName)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
        }

        static Employee()
        {
            Employee.DepartmentName = Console.ReadLine();
        }
        public void ShowEmployee()
        {
            Console.WriteLine("EmployeeID:{0}, Employee Name:{1}, Department: {2}", EmployeeID, EmployeeName, DepartmentName);
        }
    }
}
