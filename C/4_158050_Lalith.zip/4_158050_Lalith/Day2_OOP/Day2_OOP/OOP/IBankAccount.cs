﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    interface IBankAccount
    {
       double Deposit(double Amount);
       double Withdraw(double Amount);
    }
}
