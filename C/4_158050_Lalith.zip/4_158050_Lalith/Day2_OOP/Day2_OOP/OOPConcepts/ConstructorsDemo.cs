﻿using OOP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPConcepts
{
    class ConstructorsDemo
    {
        static void Main(string[] args)
        {
            //Employee Employee1 = new Employee();
            //Employee1.ShowEmployee();

            Console.WriteLine("Enter EmployeeID:");
            int EmployeeID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            string EmployeeName = Console.ReadLine();

            Employee Employee1 = new Employee(EmployeeID, EmployeeName);
            Employee1.ShowEmployee();

            Console.WriteLine("Enter EmployeeID:");
            EmployeeID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            EmployeeName = Console.ReadLine();

            Employee Employee2 = new Employee(EmployeeID, EmployeeName);
            Employee2.ShowEmployee();
        }
    }
}
