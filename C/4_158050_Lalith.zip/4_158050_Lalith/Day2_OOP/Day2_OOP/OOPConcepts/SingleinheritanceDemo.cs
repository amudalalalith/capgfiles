﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOP;
namespace OOPConcepts
{
    class SingleinheritanceDemo
    {
        static void Main(string[] args)
        {
            SavingsAccount SavingsAccount1 = new SavingsAccount("Lalith", 10000, "SalalryAccount", 4);
            Console.WriteLine("balance after deposit:" + SavingsAccount1.Deposit(5000));
            Console.WriteLine("balance after Withdrw: " + SavingsAccount1.Withdraw(7000));
            //    CurrentAccount CurrentAccount1 = new CurrentAccount("Debanjan",100000,"CurrentAccount",20000);
            //    Console.WriteLine("balance after Withdrw: " + CurrentAccount1.Withdraw(115000));
            //    Console.WriteLine("Over Draw Limit after Withdrw: " + CurrentAccount1.ShowOverdraftLimit());
            //    Console.WriteLine("balance after deposit:" + SavingsAccount1.Deposit(5000));
            //
        }
    }
}
