﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NonGenericCollection;
namespace Mainproject
{
    class StackMain
    {
        static void Main(string[] args)
        {
            MyStack myStack = new MyStack();
            myStack.SetStack();
            myStack.GetStack();
            Console.WriteLine("Next poppable value is " + myStack.GetNextPoppableValue());
        }
    }
}
