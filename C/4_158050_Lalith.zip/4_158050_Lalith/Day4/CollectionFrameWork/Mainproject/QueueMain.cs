﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NonGenericCollection;
namespace Mainproject
{
    class QueueMain
    {
        static void Main(string[] args)
        {
            MyQueue myQueue = new MyQueue();
            myQueue.SetQueue();
            myQueue.GetQueue();
            myQueue.DeleteValueQueue();
            myQueue.GetQueue();
        }
    }
}
