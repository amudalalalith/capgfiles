﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NonGenericCollection;
namespace Mainproject
{
    class HashTableMain
    {
        static void Main(string[] args)
        {
            MyHashTable myHashtable = new MyHashTable();
            myHashtable.SetHashTable();
            myHashtable.GetHashTable();
            myHashtable.SearchData(Console.ReadLine());
        }
    }
}
