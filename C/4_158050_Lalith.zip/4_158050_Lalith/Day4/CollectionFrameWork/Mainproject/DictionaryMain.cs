﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericCollection;
namespace Mainproject
{
    class DictionaryMain
    {
        static void Main(string[] args)
        {
            MyDictionary myDictionary =new MyDictionary();
            myDictionary.SetStudents();
            myDictionary.GetDetails();
            myDictionary.FindDetails(2);

        }
    }
}
