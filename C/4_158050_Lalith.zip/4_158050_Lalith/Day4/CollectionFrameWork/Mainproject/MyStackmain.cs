﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericCollection;
namespace Mainproject
{
    class MyStackmain
    {
        static void Main(string[] args)
        {


            MyStack myStack = new MyStack();
            myStack.SetStackValues();
            myStack.GetDetails();
            
            myStack.Poping();

            myStack.Peeking();
        }
    }
}