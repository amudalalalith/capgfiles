﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericCollection;
namespace Mainproject
{
    class ListMain
    {
        static void Main(string[] args)
        {
            MyList myList = new MyList();
            myList.SetCities();
            myList.GetCities();
            Console.WriteLine();
            myList.getSortedList();
           
            
            

        }
    }
}
