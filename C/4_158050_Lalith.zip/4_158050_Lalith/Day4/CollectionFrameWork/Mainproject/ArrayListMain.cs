﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NonGenericCollection;
namespace Mainproject
{
    class ArrayListMain
    {
        static void Main(string[] args)
        {
            MyArrayList MyArraList1 = new MyArrayList();
            MyArraList1.SetMyArrayList();
            MyArraList1.GetData();

        }
    }
}
