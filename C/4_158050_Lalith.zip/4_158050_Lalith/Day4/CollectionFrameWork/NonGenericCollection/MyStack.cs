﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonGenericCollection
{
public class MyStack
    {
        Stack VariedDataStack = new Stack();

        public void SetStack()
        {
            VariedDataStack.Push(10);
            VariedDataStack.Push(true);
            VariedDataStack.Push("hello");
            VariedDataStack.Push(10.32);
        }
        public void GetStack()
        {
            foreach(object o in VariedDataStack)
            {
                Console.WriteLine(o.ToString());
            }
        }
        public object GetNextPoppableValue()
        {
            return VariedDataStack.Peek();
        }

    }
}
