﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonGenericCollection
{
    public class MyQueue
    {
        Queue VariedMyQueue = new Queue();

        public void SetQueue()
        {
            VariedMyQueue.Enqueue(10);
            VariedMyQueue.Enqueue(20);
            VariedMyQueue.Enqueue("alith");
            VariedMyQueue.Enqueue(10.32);
        }

        public void GetQueue()
        {
            foreach(object o in VariedMyQueue)
            {
                Console.WriteLine(o.ToString());
            }
        }

        public void DeleteValueQueue()
        {
            Console.WriteLine(VariedMyQueue.Dequeue());
        }
    }
}
