﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonGenericCollection
{
    public class MyArrayList
    {
        ArrayList VariedParameterList=new ArrayList();
        public void SetMyArrayList()
        {
            VariedParameterList.Add(10);
            VariedParameterList.Add(10.25);
            VariedParameterList.Add("Lalith");
            VariedParameterList.Add(true);
        }

        public void GetData()
        {
            foreach (object o in VariedParameterList) 
            {
                Console.WriteLine(o.ToString());
            }
        }

    }
}
