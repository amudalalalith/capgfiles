﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonGenericCollection
{
public class MyHashTable
    {
        Hashtable VariedDataHashTable = new Hashtable();

        public void SetHashTable()
        {
            VariedDataHashTable.Add(1, "Lalith");
            VariedDataHashTable.Add("Lalith", 2);
            VariedDataHashTable.Add(true, false);
            VariedDataHashTable.Add("Hello", 10.32);
         }

        public void GetHashTable()
        {
            foreach(DictionaryEntry Entry in VariedDataHashTable)
            {
                Console.WriteLine(Entry.Key + " - " + Entry.Value);
            }
        }
        public void SearchData(object Item)
        {
            if(VariedDataHashTable.ContainsKey(Item))
                {
                Console.WriteLine(VariedDataHashTable[Item]);

            }
        }

    }
}
