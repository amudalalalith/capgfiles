﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollection
{
    public class MyList
    {
        List<string> Cities = new List<string>();
        public void SetCities()
        {
            Cities.Add("Mumbai");
            Cities.Add("Chennai");
            Cities.Add("Delhi");
            Cities.Add("Kolkata");
            Cities.Add("Hydearabad");

        }

        public void GetCities()
        {
            foreach(string City in Cities)
            {
                Console.WriteLine(City);
            }
        }

        public void getSortedList()
        {
            Cities.Sort();
            Console.WriteLine("------After Sorting------");
            
            GetCities();

        }


            
    }
}
