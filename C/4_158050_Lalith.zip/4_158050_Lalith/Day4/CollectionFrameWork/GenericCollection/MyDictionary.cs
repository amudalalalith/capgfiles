﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollection
{
    public class MyDictionary
    {
        Dictionary<int, string> StudentDetails = new Dictionary<int, string>();
        public void SetStudents()
        {
            StudentDetails.Add(1, "Lalith");
            StudentDetails.Add(2, "Lalit");
            StudentDetails.Add(3, "Lali");
            StudentDetails.Add(4, "Lal");
            StudentDetails.Add(5, "Lah");
            StudentDetails.Add(6, "La");

        }
        public void GetDetails()
        {
            foreach (KeyValuePair<int, string> Entry in StudentDetails)
            {
                Console.WriteLine(Entry.Key + " - " + Entry.Value);
            }
        }
        public void FindDetails(int key)
        {
            if (StudentDetails.ContainsKey(key))
            {
                Console.WriteLine(StudentDetails[key]);
            }
        }
    }
}