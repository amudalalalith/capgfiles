﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollection
{  public class MyStack
    {
        Stack<int> myStack = new Stack<int>();
        public void SetStackValues()
        {
            myStack.Push(25);
            myStack.Push(36);
            myStack.Push(45);
            myStack.Push(55);
            myStack.Push(66);
        }
        public void GetDetails()
        {
            foreach(int i in myStack)
            {
                Console.WriteLine(i);
            }
        }
        public void Poping()
        {
            myStack.Pop();
            Console.WriteLine();
            GetDetails();
        }
        public void Peeking()
        {
            Console.WriteLine();
            myStack.Peek();
        }
    }
}
