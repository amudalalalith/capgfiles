﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesAndDirectories
{
    class IOStream
    {
        

        static void Main(string[] args)
        {
            FileStream fileStream = new FileStream(@"D:\Project 1\Day4\sample.txt", FileMode.Create, FileAccess.Write);
            string message = "This is an Example of FileStream using System.IO";
            byte[] writeData = new byte[message.Length];
            writeData = Encoding.ASCII.GetBytes(message);
            fileStream.Write(writeData, 0, writeData.Length);
            fileStream.Close();
            
            Console.WriteLine("Data Written Sucessfully");

           
        }
    }
}
