﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FilesAndDirectories
{
    class DiretoryMain
    {
        static void Main(string[] args)
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"D:\Project 1\Day3\ExceptionTask\MainImplementation");
            if (directoryInfo.Exists)
            {
                Console.WriteLine("Directory Name : " + directoryInfo.Name);
                Console.WriteLine("Parent Directory: " + directoryInfo.Parent);
                Console.WriteLine("Directory CreationTime: " + directoryInfo.CreationTime);
                Console.WriteLine("Directory Path : " + directoryInfo.FullName);

                FileInfo[] filesInfo = directoryInfo.GetFiles();
                Console.WriteLine("Total files in Directory are" + filesInfo.Length);
                foreach(FileInfo file in filesInfo)
                {
                    Console.WriteLine(file.Name);
                }

                DirectoryInfo[] directoriesInfo = directoryInfo.GetDirectories();
                Console.WriteLine("Total files in Directory are" + directoriesInfo.Length);
                foreach (DirectoryInfo directory in directoriesInfo)
                {
                    Console.WriteLine(directory.Name);
                }
            }
            else
            {
                Console.WriteLine("Invalid Directory");
            }
        }
    }
}
