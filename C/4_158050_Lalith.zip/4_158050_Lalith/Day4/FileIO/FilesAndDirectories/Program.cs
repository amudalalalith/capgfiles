﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FilesAndDirectories
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo flieInfo = new FileInfo(@"D:\Project 1\Day3\ExceptionTask\MainImplementation\Program.cs");
            if(flieInfo.Exists)
            {
                Console.WriteLine("File Name : " + flieInfo.Name);
                Console.WriteLine("File Extension : " + flieInfo.Extension);
                Console.WriteLine("File Path : " + flieInfo.FullName);
                Console.WriteLine("File S   " + flieInfo.Length);
                Console.WriteLine("File LastAccessTime: " + flieInfo.LastAccessTime);
                Console.WriteLine("File CreationTime: " + flieInfo.CreationTime);
                Console.WriteLine("File Directory : " + flieInfo.Directory);
            }
            else
            {
                Console.WriteLine("Invalid File");
            }
        }
    }
}
