﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace FilesAndDirectories
{
    class ReadString
    {
        static void Main(string[] args)
        {


            FileStream fileStream1 = new FileStream(@"D:\Project 1\Day4\sample.txt", FileMode.Open, FileAccess.Read);

            byte[] readData = new byte[fileStream1.Length];

            fileStream1.Read(readData, 0, readData.Length);

            //foreach (byte b in readData)
            //{

            //    Console.Write(b + "\t");
            //}

            string data = Encoding.ASCII.GetString(readData);
            Console.WriteLine(data);

            fileStream1.Close();
        }   
    }
}
