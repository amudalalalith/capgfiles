﻿using System;
using CalculatorLibrary;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClientProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Choise");
            Console.WriteLine("1. ADD");
            Console.WriteLine("2. SUbstraction");
            Console.WriteLine("3. MULTIPLICATION");
            Console.WriteLine("4. DIVISION");
            int Choise = int.Parse(Console.ReadLine());
            Console.Write("Enter Number1:");
            int Number1 = int.Parse(Console.ReadLine());
            Console.Write("Enter Number2:");
            int Number2 = int.Parse(Console.ReadLine());

            int Result = 0;
            Calculator calculator = new Calculator();

            switch (Choise)
            {
                case 1:
                    Result = calculator.Add(Number1, Number2);
                    //Result = Add(Number1, Number2);
                    break;

                case 2:
                    Result = calculator.Sub(Number1, Number2);
                    //Result = Sub(Number1, Number2);
                    break;

                case 3:
                    Result = calculator.Mul(Number1, Number2);
                    //Result = Mul(Number1, Number2);
                    break;

                case 4:
                    Result = calculator.Div(Number1, Number2);
                    //Result = Div(Number1, Number2);
                    break;

                default:
                    Console.WriteLine("Invalid Operation");
                    break;
            }
            Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
        }
    }
}
