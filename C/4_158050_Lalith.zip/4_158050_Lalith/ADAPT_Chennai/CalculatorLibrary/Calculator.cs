﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
    public class Calculator
    {
        public int Add(int Number1, int Number2)
        {
            int Result = Number1 + Number2;
            return Result;
        }
        public int Sub(int Number1, int Number2)
        {
            int Result = Number1 - Number2;
            return Result;
        }
        public int Mul(int Number1, int Number2)
        {
            int Result = Number1 * Number2;
            return Result;
        }
        public int Div(int Number1, int Number2)
        {
            int Result = Number1 / Number2;
            return Result;
        }
    }
}
