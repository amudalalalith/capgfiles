﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GettingStarted
{
    class StudentDemo
    {
        static void Main(string[] args)
        {
            Student.PrintCounter();

            Student student1 = new Student();
            Console.WriteLine(student1.Rollnumber);
            Student student2 = new Student();
            Console.WriteLine(student2.Rollnumber); // look at the callinf of the function

            Console.WriteLine(Student.Counter);

            Student.PrintCounter();
        }
        
    }
}
