﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GettingStarted
{
    class IfCalculator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number1:");
            int Number1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Number2:");
            int Number2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Please select operation");
            Console.WriteLine("1. ADDITION");
            Console.WriteLine("2. SUbstraction");
            Console.WriteLine("3. MULTIPLICATION" );
            Console.WriteLine("4. DIVISION");

            int Choise = int.Parse(Console.ReadLine());
            int Result;
            if (Choise == 1)
            {
                Result = Add(Number1, Number2);
                Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
            }
            else if (Choise == 2)
            {
                Result = Sub(Number1, Number2);
                Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
            }
            else if (Choise == 3)
            {
                Result = Mul(Number1, Number2);
                Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
            }
            else if (Choise == 4)
            {
                Result = Div(Number1, Number2);
                Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
            }
            else
            {
                Console.WriteLine("invalid Choise");
            }

        }
        static int Add(int Number1, int Number2)
        {
            int Result = Number1 + Number2;
            return Result;
        }
        static int Sub(int Number1, int Number2)
        {
            int Result = Number1 - Number2;
            return Result;
        }
        static int Mul(int Number1, int Number2)
        {
            int Result = Number1 * Number2;
            return Result;
        }
        static int Div(int Number1, int Number2)
        {
            int Result = Number1 / Number2;
            return Result;
        }
    }
}
