﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GettingStarted
{
    class Student
    {
        public int Rollnumber;
        public string Name;
        public string Class;

        public static int Counter = 0;
        public Student()
        {
            Rollnumber = ++Counter;
        }

        public static void PrintCounter()
        {
            Console.WriteLine(Counter);
            ++Counter;
        }

    }
}
