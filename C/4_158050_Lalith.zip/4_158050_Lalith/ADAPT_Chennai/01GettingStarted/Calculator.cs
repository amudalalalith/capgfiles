﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GettingStarted
{
    class Calculator
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number1:");
            int Number1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Number2:");
            int Number2 = int.Parse(Console.ReadLine());

            int Result = Number1 + Number2;
            Console.WriteLine("Number1 is : {0}, Number2 is : {1}, Result is : {2}", Number1, Number2, Result);
            
        }
    }
}
