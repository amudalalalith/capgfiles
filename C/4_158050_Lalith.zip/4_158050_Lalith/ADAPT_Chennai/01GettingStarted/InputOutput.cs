﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01GettingStarted
{
    class InputOutput
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name: ");
            string Name = Console.ReadLine();
            int marks = 20;
            Console.WriteLine("Hello, {0} has scored {1}", Name, marks);
        }
    }
}
