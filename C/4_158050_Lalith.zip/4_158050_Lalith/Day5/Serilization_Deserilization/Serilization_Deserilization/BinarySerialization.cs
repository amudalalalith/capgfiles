﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serilization_Deserilization
{
    class BinarySerialization
    {
        static List<Student> students = new List<Student>();

        static public void AddStudent()
        {
            students.Add(new Student() { StudentId = 1, StudentName = "Lalith" });
            students.Add(new Student() { StudentId = 2, StudentName = "DEbankajn" });
            students.Add(new Student() { StudentId = 3, StudentName = "Gautham" });
            students.Add(new Student() { StudentId = 4, StudentName = "Debi" });

        }

        static public void SerializeStudent()
        {
            FileStream fileStream = new FileStream("Student.txt", FileMode.Create);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fileStream, students);
            fileStream.Close();
        }

        static public List<Student> DeserializeStudent()
        {
            FileStream fs = new FileStream("Student.txt", FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            List<Student> deserializedList = new List<Student>();
            deserializedList = (List < Student > )formatter.Deserialize(fs);
            return deserializedList;
        }

        static void Main(string[] args)
        {
            AddStudent();
            SerializeStudent();
            List<Student> StudentList = DeserializeStudent();
            Console.WriteLine("List of Students after Deserialization are : " );
            foreach(Student student in StudentList)
            {
                Console.Write(student.StudentId);
                Console.Write(" - ");
                Console.Write(student.StudentName);
                Console.WriteLine();
            }

        }
    }
    [Serializable]
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
    }
}
