﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Soap;
namespace Serilization_Deserilization
{
    class SOAPSerialization
    {
        static List<Student> students = new List<Student>();

        static public void AddStudent()
        {
            students.Add(new Student() { StudentId = 1, StudentName = "Lalith" });
            students.Add(new Student() { StudentId = 2, StudentName = "DEbankajn" });
            students.Add(new Student() { StudentId = 3, StudentName = "Gautham" });
            students.Add(new Student() { StudentId = 4, StudentName = "Debi" });

        }

        static public void SerializeStudent()
        {
            FileStream fileStream = new FileStream("StudentsSOAP.txt", FileMode.Create);
            SoapFormatter formatter = new SoapFormatter();
            formatter.Serialize(fileStream, students);
            fileStream.Close();
        }

        static public List<Student> DeserializeStudent()
        {
            FileStream fs = new FileStream("StudentsSOAP.txt", FileMode.Open);
            SoapFormatter formatter = new SoapFormatter();
            List<Student> deserializedList = new List<Student>();
            deserializedList = (List<Student>)formatter.Deserialize(fs);
            return deserializedList;
        }

        static void Main(string[] args)
        {
            AddStudent();
            SerializeStudent();
            List<Student> StudentList = DeserializeStudent();
            Console.WriteLine("List of Students after Deserialization are : ");
            foreach (Student student in StudentList)
            {
                Console.Write(student.StudentId);
                Console.Write(" - ");
                Console.Write(student.StudentName);
                Console.WriteLine();
            }

        }
    }


}
