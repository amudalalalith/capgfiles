﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSExceptions
{
    /// <summary>
    /// Exception Class to Catch the Exception Occuring in SMS
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentException : ApplicationException
    {
        // Default Constructor, that inherits the Base Constructor
        public StudentException() : base() { }

            //Parameterized constructor for Passing the Error/Exception Message
            public StudentException(string Message) : base(Message) { }
    }
}
