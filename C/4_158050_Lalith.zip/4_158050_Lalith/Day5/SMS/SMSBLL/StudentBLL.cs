﻿using System;
using SMSDAL;
using SMSEntities;
using SMSExceptions;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSBLL
{
    /// <summary>
    /// To create the validations metods and to Invoke the Operations from DAL 
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentBLL
    {
        static List<Student> sList = new List<Student>();
        public bool AddStudentBL(Student student)
        {
            StudentDAL studentOperations = new StudentDAL();
            bool isAdded;

            try
            {
                isAdded = studentOperations.AddStudentDAL(student);
                if(isAdded == false)
                {
                    throw new StudentException("Student Details Not Added");
                }

            }
            catch(StudentException e)
            {
                throw e;
            }

            return isAdded;
        }

        public List<Student> DisplayStudentBL()
        {
            StudentDAL studentOperations = new StudentDAL();
            try
            {
                sList = studentOperations.DisplayStudentDAL();
                if (sList.Count <= 0)
                {
                    throw new StudentException("No Records Found!!!");

                }
            }
            catch (StudentException e)
            {
                throw e;
            }

            return sList;
        }

    }
}
