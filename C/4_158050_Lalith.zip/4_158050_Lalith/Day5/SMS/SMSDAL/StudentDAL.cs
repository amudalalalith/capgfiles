﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using SMSEntities;
using SMSExceptions;
namespace SMSDAL
{
    /// <summary>
    /// To Create the metods for performing operations on Student Entity
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentDAL
    {
        static List<Student> studentList = new List<Student>();
        ///<summary>
        ///function for inserting student Data into the List
        ///</summary>
        ///<param name="newstudent"></param>
        ///<return>boolean value if user is added or not</return>
        public bool AddStudentDAL(Student newsstudent)
        {
            bool isStudentAdded = false;
            try
            {
                studentList.Add(newsstudent);

                ///
                FileStream fileStream = new FileStream("Student.txt", FileMode.Create);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fileStream, newsstudent);
                fileStream.Close();
                ////
                isStudentAdded = true;
            }
            catch(StudentException)
            {
                throw;

            }
            return isStudentAdded;

        }

        /// <summary>
        /// Function for displaying the data from the studentList
        /// </summary>
        /// <returns></returns>
        public List<Student> DisplayStudentDAL()
        {

            return studentList;
        }
    }

    
}
