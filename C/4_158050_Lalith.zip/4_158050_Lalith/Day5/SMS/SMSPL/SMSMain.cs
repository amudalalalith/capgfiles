﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMSBLL;
using SMSEntities;
using SMSExceptions;

namespace SMSPL
{
    /// <summary>
    /// Console Application to Manage the Student Information
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    class SMSMain
    {

        public static void AddStudentPL()
        {
            try
            {
                Student objStudent = new Student();
                Console.WriteLine("Enter the Student ID :");
                bool chkid;
                int sid;
                //Use TryParse to chk if the entered value is parseable or not
                chkid = Int32.TryParse(Console.ReadLine(), out sid);
                //If the Parsing fails, throw the Exception
                if (chkid == false)
                {
                    throw new StudentException("Invalid Entry");
                }
                // If the Parsing is successful, store the StudentId into the Entity object
                else
                {
                    objStudent.StudentId = sid;
                }
                Console.WriteLine("Enter Student Name:");
                objStudent.StudentName = Console.ReadLine();
                Console.WriteLine("Enter the Grade:");
                objStudent.StudentGrade = (Grade)Enum.Parse(typeof(Grade), Console.ReadLine());

                StudentBLL bllobj = new StudentBLL();
                if (bllobj.AddStudentBL(objStudent) == false)
                {
                    throw new StudentException("Student Record could not be added");

                }
                else
                {
                    Console.WriteLine("Student Details Added Successfully");
                }
            }

            catch (StudentException Exception)
            {
                Console.WriteLine("Error occurred " + Exception.Message);
            }
        }

        public static void DisplayStudentPL()
        {
            try
            {
                StudentBLL bllobj = new StudentBLL();
                List<Student> sList = new List<Student>();
                sList = bllobj.DisplayStudentBL();
                Console.WriteLine("Student Details");
                Console.WriteLine("=================");
                foreach (Student s in sList)
                {
                    Console.WriteLine("Student Id :{0}\n Student Name :{1} \n Student Grade :{2}", s.StudentId, s.StudentName, s.StudentGrade);

                }

            }
            catch (StudentException e)
            {
                Console.WriteLine(e.Message);
            }

        }
        static void Main(string[] args)
        {
            AddStudentPL();
            AddStudentPL();
            DisplayStudentPL();
        }
    }
}

    


