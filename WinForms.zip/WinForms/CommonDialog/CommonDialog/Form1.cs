﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CommonDialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnMessage_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Message Box is Displayed", "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                MessageBox.Show("Ok Button Clicked", "OK");
            }
            else if (result == DialogResult.Cancel)
            {
                MessageBox.Show("Cancel Button Click", "Cancel");
            }
        }

        private void btnCustom_Click(object sender, EventArgs e)
        {
            CustomDialog custom = new CustomDialog();
            custom.ShowDialog();

        }

        
    }
}
