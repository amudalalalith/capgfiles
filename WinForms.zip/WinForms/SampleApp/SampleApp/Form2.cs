﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome", "Capgemini", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            Label lbl_msg = new Label();
            lbl_msg.Text = "Win Form";
            lbl_msg.ForeColor = Color.Red;
            lbl_msg.BackColor = Color.LightCoral;
            this.Controls.Add(lbl_msg);  

        }
    }
}
