﻿namespace ControlsDemo
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeForm));
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.textEmployeeId = new System.Windows.Forms.TextBox();
            this.EmployeeName = new System.Windows.Forms.Label();
            this.txtEmployeename = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.Label();
            this.rdbmale = new System.Windows.Forms.RadioButton();
            this.rdbfemale = new System.Windows.Forms.RadioButton();
            this.lblSalary = new System.Windows.Forms.Label();
            this.rdb20000 = new System.Windows.Forms.RadioButton();
            this.rdb40000 = new System.Windows.Forms.RadioButton();
            this.rdb60000 = new System.Windows.Forms.RadioButton();
            this.rdbgrt60000 = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.grbGender = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grbGender.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(34, 36);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.Size = new System.Drawing.Size(83, 16);
            this.lblEmployeeID.TabIndex = 0;
            this.lblEmployeeID.Text = "EmployeeID";
            // 
            // textEmployeeId
            // 
            this.textEmployeeId.Location = new System.Drawing.Point(139, 32);
            this.textEmployeeId.Name = "textEmployeeId";
            this.textEmployeeId.Size = new System.Drawing.Size(153, 20);
            this.textEmployeeId.TabIndex = 1;
            // 
            // EmployeeName
            // 
            this.EmployeeName.AutoSize = true;
            this.EmployeeName.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeName.Location = new System.Drawing.Point(34, 90);
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.Size = new System.Drawing.Size(92, 15);
            this.EmployeeName.TabIndex = 2;
            this.EmployeeName.Text = "Employee Name";
            this.EmployeeName.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtEmployeename
            // 
            this.txtEmployeename.Location = new System.Drawing.Point(139, 85);
            this.txtEmployeename.Multiline = true;
            this.txtEmployeename.Name = "txtEmployeename";
            this.txtEmployeename.Size = new System.Drawing.Size(153, 20);
            this.txtEmployeename.TabIndex = 3;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender.Location = new System.Drawing.Point(34, 126);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(44, 15);
            this.Gender.TabIndex = 4;
            this.Gender.Text = "Gender";
            // 
            // rdbmale
            // 
            this.rdbmale.AutoSize = true;
            this.rdbmale.Location = new System.Drawing.Point(6, 29);
            this.rdbmale.Name = "rdbmale";
            this.rdbmale.Size = new System.Drawing.Size(48, 17);
            this.rdbmale.TabIndex = 0;
            this.rdbmale.TabStop = true;
            this.rdbmale.Text = "Male";
            this.rdbmale.UseVisualStyleBackColor = true;
            // 
            // rdbfemale
            // 
            this.rdbfemale.AutoSize = true;
            this.rdbfemale.Location = new System.Drawing.Point(80, 29);
            this.rdbfemale.Name = "rdbfemale";
            this.rdbfemale.Size = new System.Drawing.Size(59, 17);
            this.rdbfemale.TabIndex = 1;
            this.rdbfemale.TabStop = true;
            this.rdbfemale.Text = "Female";
            this.rdbfemale.UseVisualStyleBackColor = true;
            this.rdbfemale.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalary.Location = new System.Drawing.Point(76, 233);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(41, 15);
            this.lblSalary.TabIndex = 6;
            this.lblSalary.Text = "Salary";
            this.lblSalary.Click += new System.EventHandler(this.lblSalary_Click);
            // 
            // rdb20000
            // 
            this.rdb20000.AutoSize = true;
            this.rdb20000.Location = new System.Drawing.Point(17, 13);
            this.rdb20000.Name = "rdb20000";
            this.rdb20000.Size = new System.Drawing.Size(61, 17);
            this.rdb20000.TabIndex = 0;
            this.rdb20000.TabStop = true;
            this.rdb20000.Text = "<20000";
            this.rdb20000.UseVisualStyleBackColor = true;
            this.rdb20000.CheckedChanged += new System.EventHandler(this.rdb20000_CheckedChanged);
            // 
            // rdb40000
            // 
            this.rdb40000.AutoSize = true;
            this.rdb40000.Location = new System.Drawing.Point(102, 13);
            this.rdb40000.Name = "rdb40000";
            this.rdb40000.Size = new System.Drawing.Size(100, 17);
            this.rdb40000.TabIndex = 1;
            this.rdb40000.TabStop = true;
            this.rdb40000.Text = "20000 to 40000";
            this.rdb40000.UseVisualStyleBackColor = true;
            this.rdb40000.CheckedChanged += new System.EventHandler(this.rdb40000_CheckedChanged);
            // 
            // rdb60000
            // 
            this.rdb60000.AutoSize = true;
            this.rdb60000.Location = new System.Drawing.Point(17, 36);
            this.rdb60000.Name = "rdb60000";
            this.rdb60000.Size = new System.Drawing.Size(100, 17);
            this.rdb60000.TabIndex = 2;
            this.rdb60000.TabStop = true;
            this.rdb60000.Text = "40000 to 60000";
            this.rdb60000.UseVisualStyleBackColor = true;
            this.rdb60000.CheckedChanged += new System.EventHandler(this.rdb60000_CheckedChanged);
            // 
            // rdbgrt60000
            // 
            this.rdbgrt60000.AutoSize = true;
            this.rdbgrt60000.Location = new System.Drawing.Point(123, 36);
            this.rdbgrt60000.Name = "rdbgrt60000";
            this.rdbgrt60000.Size = new System.Drawing.Size(61, 17);
            this.rdbgrt60000.TabIndex = 3;
            this.rdbgrt60000.TabStop = true;
            this.rdbgrt60000.Text = ">60000";
            this.rdbgrt60000.UseVisualStyleBackColor = true;
            this.rdbgrt60000.CheckedChanged += new System.EventHandler(this.rdbgrt60000_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(298, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(112, 69);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(79, 302);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(28, 15);
            this.lblCity.TabIndex = 8;
            this.lblCity.Text = "City";
            this.lblCity.Click += new System.EventHandler(this.lblCity_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Pune",
            "Mumbai",
            "Hyderabad",
            "Banglore",
            "Chennai",
            "Noida"});
            this.comboBox1.Location = new System.Drawing.Point(178, 302);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 9;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(151, 344);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 10;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // grbGender
            // 
            this.grbGender.Controls.Add(this.rdbmale);
            this.grbGender.Controls.Add(this.rdbfemale);
            this.grbGender.Location = new System.Drawing.Point(139, 126);
            this.grbGender.Name = "grbGender";
            this.grbGender.Size = new System.Drawing.Size(153, 60);
            this.grbGender.TabIndex = 5;
            this.grbGender.TabStop = false;
            this.grbGender.Text = "Gender";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.rdb20000);
            this.panel1.Controls.Add(this.rdb40000);
            this.panel1.Controls.Add(this.rdb60000);
            this.panel1.Controls.Add(this.rdbgrt60000);
            this.panel1.Location = new System.Drawing.Point(139, 205);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(201, 74);
            this.panel1.TabIndex = 7;
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(567, 357);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grbGender);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.txtEmployeename);
            this.Controls.Add(this.EmployeeName);
            this.Controls.Add(this.textEmployeeId);
            this.Controls.Add(this.lblEmployeeID);
            this.Name = "EmployeeForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grbGender.ResumeLayout(false);
            this.grbGender.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.TextBox textEmployeeId;
        private System.Windows.Forms.Label EmployeeName;
        private System.Windows.Forms.TextBox txtEmployeename;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.RadioButton rdbmale;
        private System.Windows.Forms.RadioButton rdbfemale;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.RadioButton rdb20000;
        private System.Windows.Forms.RadioButton rdb40000;
        private System.Windows.Forms.RadioButton rdb60000;
        private System.Windows.Forms.RadioButton rdbgrt60000;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox grbGender;
        private System.Windows.Forms.Panel panel1;
    }
}

