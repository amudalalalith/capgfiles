﻿namespace MenuDemo
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuItemsForms = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemForm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemForm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDialog = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemColor = new System.Windows.Forms.ToolStripMenuItem();
            this.formsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemMessageBox = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemPreview = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemLayout = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemHorizantal = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemVertical = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemCascade = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemsForms,
            this.MenuItemDialog,
            this.MenuItemLayout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(475, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuItemsForms
            // 
            this.MenuItemsForms.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemForm1,
            this.MenuItemForm2,
            this.MenuItemExit});
            this.MenuItemsForms.Name = "MenuItemsForms";
            this.MenuItemsForms.Size = new System.Drawing.Size(52, 20);
            this.MenuItemsForms.Text = "Forms";
            // 
            // MenuItemForm1
            // 
            this.MenuItemForm1.Name = "MenuItemForm1";
            this.MenuItemForm1.Size = new System.Drawing.Size(152, 22);
            this.MenuItemForm1.Text = "Form1";
            this.MenuItemForm1.Click += new System.EventHandler(this.MenuItemForm1_Click);
            // 
            // MenuItemForm2
            // 
            this.MenuItemForm2.Name = "MenuItemForm2";
            this.MenuItemForm2.Size = new System.Drawing.Size(152, 22);
            this.MenuItemForm2.Text = "Form2";
            this.MenuItemForm2.Click += new System.EventHandler(this.MenuItemForm2_Click);
            // 
            // MenuItemExit
            // 
            this.MenuItemExit.Name = "MenuItemExit";
            this.MenuItemExit.Size = new System.Drawing.Size(152, 22);
            this.MenuItemExit.Text = "Exit";
            this.MenuItemExit.Click += new System.EventHandler(this.MenuItemExit_Click);
            // 
            // MenuItemDialog
            // 
            this.MenuItemDialog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemColor,
            this.formsToolStripMenuItem,
            this.MenuItemMessageBox,
            this.MenuItemPreview});
            this.MenuItemDialog.Name = "MenuItemDialog";
            this.MenuItemDialog.Size = new System.Drawing.Size(72, 20);
            this.MenuItemDialog.Text = "DialogBox";
            // 
            // MenuItemColor
            // 
            this.MenuItemColor.Name = "MenuItemColor";
            this.MenuItemColor.Size = new System.Drawing.Size(152, 22);
            this.MenuItemColor.Text = "Color";
            this.MenuItemColor.Click += new System.EventHandler(this.MenuItemColor_Click);
            // 
            // formsToolStripMenuItem
            // 
            this.formsToolStripMenuItem.Name = "formsToolStripMenuItem";
            this.formsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.formsToolStripMenuItem.Text = "Font";
            this.formsToolStripMenuItem.Click += new System.EventHandler(this.formsToolStripMenuItem_Click);
            // 
            // MenuItemMessageBox
            // 
            this.MenuItemMessageBox.Name = "MenuItemMessageBox";
            this.MenuItemMessageBox.Size = new System.Drawing.Size(152, 22);
            this.MenuItemMessageBox.Text = "MessageBox";
            this.MenuItemMessageBox.Click += new System.EventHandler(this.MenuItemMessageBox_Click);
            // 
            // MenuItemPreview
            // 
            this.MenuItemPreview.Name = "MenuItemPreview";
            this.MenuItemPreview.Size = new System.Drawing.Size(152, 22);
            this.MenuItemPreview.Text = "PrintPreview";
            this.MenuItemPreview.Click += new System.EventHandler(this.MenuItemPreview_Click);
            // 
            // MenuItemLayout
            // 
            this.MenuItemLayout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemHorizantal,
            this.MenuItemVertical,
            this.MenuItemCascade});
            this.MenuItemLayout.Name = "MenuItemLayout";
            this.MenuItemLayout.Size = new System.Drawing.Size(55, 20);
            this.MenuItemLayout.Text = "Layout";
            // 
            // MenuItemHorizantal
            // 
            this.MenuItemHorizantal.Name = "MenuItemHorizantal";
            this.MenuItemHorizantal.Size = new System.Drawing.Size(152, 22);
            this.MenuItemHorizantal.Text = "Horizantal";
            this.MenuItemHorizantal.Click += new System.EventHandler(this.MenuItemHorizantal_Click);
            // 
            // MenuItemVertical
            // 
            this.MenuItemVertical.Name = "MenuItemVertical";
            this.MenuItemVertical.Size = new System.Drawing.Size(152, 22);
            this.MenuItemVertical.Text = "Vertical";
            this.MenuItemVertical.Click += new System.EventHandler(this.MenuItemVertical_Click);
            // 
            // MenuItemCascade
            // 
            this.MenuItemCascade.Name = "MenuItemCascade";
            this.MenuItemCascade.Size = new System.Drawing.Size(152, 22);
            this.MenuItemCascade.Text = "Cascade";
            this.MenuItemCascade.Click += new System.EventHandler(this.MenuItemCascade_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 301);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainWindow";
            this.Text = "Main Window";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemsForms;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForm1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForm2;
        private System.Windows.Forms.ToolStripMenuItem MenuItemExit;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDialog;
        private System.Windows.Forms.ToolStripMenuItem MenuItemColor;
        private System.Windows.Forms.ToolStripMenuItem formsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemMessageBox;
        private System.Windows.Forms.ToolStripMenuItem MenuItemPreview;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLayout;
        private System.Windows.Forms.ToolStripMenuItem MenuItemHorizantal;
        private System.Windows.Forms.ToolStripMenuItem MenuItemVertical;
        private System.Windows.Forms.ToolStripMenuItem MenuItemCascade;
    }
}

