﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoutedEventsDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("button mousedown!");
        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("StackPanel mousedown!");
            //e.Handled = true;
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Grid mousedown!");
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Window mousedown!");
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Border mousedown!");
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Window PreviewMousedown!");
        }

        private void Border_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Border PreviewMousedown!");

        }

        private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("Grid PreviewMousedown!");
        }

        private void StackPanel_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("StackPanel PreviewMousedown!");
        }

        private void btn1_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            lst1.Items.Add("button PreviewMousedown!");
        }

        private void txt1_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key  == Key.Escape)
                e.Handled = true;
        }

        private void txt1_KeyDown(object sender, KeyEventArgs e)
        {
            Debug.WriteLine("textbox keydown!");
        }
    }
}
