﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for ShowProduct.xaml
    /// </summary>
    public partial class ShowProduct : Window
    {
        public ShowProduct()
        {
            InitializeComponent();
        }

        Product obj;
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            obj = (Product)this.FindResource("product1");
            Debug.WriteLine(obj.Id);
            Debug.WriteLine(obj.Name);
            Debug.WriteLine(obj.UnitCost);
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            Product newObj = new Product(); //1 IPHONE 6S 60000
            newObj.Id = 101;
            newObj.Name = "Lumia";
            newObj.UnitCost = 20000;
            Grid1.DataContext = newObj;

        }
    }
}
