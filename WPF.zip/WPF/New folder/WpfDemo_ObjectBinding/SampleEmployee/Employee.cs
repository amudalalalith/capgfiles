﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows;

namespace SampleEmployee
{
     class Employee:DependencyObject 
    {
         
         public int EmployeeId
        {
            get { return (int)GetValue(EmployeeIdProperty); }
            set { SetValue(EmployeeIdProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EmployeeId.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EmployeeIdProperty =
            DependencyProperty.Register("EmployeeId", typeof(int), typeof(Employee), new PropertyMetadata(0));

        public string EmployeeName
        {
            get { return (string)GetValue(EmployeeNameProperty); }
            set { SetValue(EmployeeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EmployeeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EmployeeNameProperty =
            DependencyProperty.Register("EmployeeName", typeof(string), typeof(Employee), new PropertyMetadata(""));


        public string Department
        {
            get { return (string)GetValue(DepartmentProperty); }
            set { SetValue(DepartmentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Department.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DepartmentProperty =
            DependencyProperty.Register("Department", typeof(string), typeof(Employee), new PropertyMetadata(""));


        

        
    }
}
