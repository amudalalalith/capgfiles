﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SampleEmployee
{
    /// <summary>
    /// Interaction logic for EmpDependency.xaml
    /// </summary>
    public partial class EmpDependency : Window
    {
        Employee emp;
        EmployeeDetails empDetails;
        
        public EmpDependency()
        {
            InitializeComponent();
            emp = new Employee();
            empDetails = new EmployeeDetails();
            emp = empDetails.GetEmployee();
            this.DataContext = emp;
        }
        

        private void btn_Print_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(emp.EmployeeName, emp.Department);
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            emp.EmployeeName = "Vaishali";
            emp.Department = "LnD";

        }

        
    }
}
