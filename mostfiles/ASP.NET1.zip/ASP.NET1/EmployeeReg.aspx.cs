﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EmployeeReg : System.Web.UI.Page
{
    SqlConnection cn = null;
    SqlCommand cmd = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }

    protected void btn_Submit_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection(ConfigurationManager.ConnectionStrings["8Aug_SipcotConnectionString"].ConnectionString);
        cmd = new SqlCommand("Lalith.USP_InsertDetails_158050", cn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@empId", txt_empID.Text);
        cmd.Parameters.AddWithValue("@empName", txt_empName.Text);
        cmd.Parameters.AddWithValue("@empEmail", txt_Email.Text);
        cmd.Parameters.AddWithValue("@empPhone", txt_PhNo.Text);
        cmd.Parameters.AddWithValue("@empDob", txt_DOB.Text);
        cmd.Parameters.AddWithValue("@empPwd", txt_Pwd.Text);
        cn.Open();
      
        try
        {
          cmd.ExecuteNonQuery();
            lbl_Msg.Text = "Registered";
           // Response.Redirect("LoginPage.aspx");
        }
        catch(Exception ex)
        {
            lbl_Msg.Text = ex.Message.ToString();
        }
        finally
        {
            cn.Close();
        }

         

    }
}