﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginPage : System.Web.UI.Page
{
    SqlConnection cn = null;
    SqlCommand cmd = null;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_Login_Click(object sender, EventArgs e)
    {
        cn = new SqlConnection(ConfigurationManager.ConnectionStrings["8Aug_SipcotConnectionString"].ConnectionString);
        cmd = new SqlCommand("Lalith.USP_ValidateDetails_158050", cn);
        SqlDataReader dr;
        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@empId", txt_Uid.Text);
        cmd.Parameters.AddWithValue("@empPwd", txt_Pwd.Text);
        cn.Open();

      
        try
        {
           
           dr= cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                string id = dr[0].ToString();
                Session["user"] = id;
                Response.Redirect("WelcomePage.aspx");
            }
            else
                lbl_valid.Text = "Invalid User";
        }
        catch(Exception ex)
        {
            lbl_valid.Text = ex.Message.ToString();
        }
        finally
        {
            cn.Close();
        }
    }
}