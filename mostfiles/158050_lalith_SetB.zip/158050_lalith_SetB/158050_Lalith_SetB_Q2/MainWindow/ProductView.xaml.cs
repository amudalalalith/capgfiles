﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MainWindow
{
    /// <summary>
    /// Interaction logic for ProductView.xaml
    /// </summary>
    public partial class ProductView : Window
    {
        public ProductView()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Entities dbContext = new Entities();

            ///<summary>
            ///Getting Details from Dtatbase using dbContext from Entities Class
            /// </summary>

            List<Product> prods = dbContext.Products.ToList();

            ///<summary>
            ///New list to store the values of the objects
            /// </summary>

            List<Product> p = new List<Product>();

            ///<summary>
            ///LINQ query to get the required values
            /// </summary>
            var res1 = from pro in prods
                       where pro.ProductName.StartsWith("Ch")
                       select pro;

            foreach (var item in res1)
            {
                p.Add(item);
            }

            //Displaying the values in the data Grid
            dgProduct.ItemsSource = p;

        }
    }
}
