﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PM_Entities;
using PM_Exceptions;

using System.Configuration;
using System.Data.SqlClient;

namespace PM_DAL
{
    public class ProductDAL
    {
        /// <summary>
        /// Defining the Database Connectivity Variables
        /// </summary>
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        /// <summary>
        /// Passing the connection
        /// </summary>
        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        /// <summary>
        /// selecting the details of the table
        /// </summary>
        /// <returns></returns>
        public List<Product> SelectAll()
        {
            List<Product> Prod = new List<Product>();
            try
            {
                //cmd = new SqlCommand("select * from Lalith.Product", cn);

                cmd = new SqlCommand("Lalith.USP_SELECT_PRODUCT", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();

                while(dr.Read())
                {
                    Product p = new Product();
                    p.ProductId = Convert.ToInt32(dr[0]);
                    p.Productname = dr[1].ToString();
                    p.ProductDescription = dr[2].ToString();
                    p.Productprice = Convert.ToDouble(dr[3]);

                    Prod.Add(p);
                }

            }
            catch(ProductException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return Prod;
        }

        /// <summary>
        /// Inserting function to insert in the database
        /// </summary>
       
        /// <returns></returns>
        public int Insert(Product Prod)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("Lalith.USP_INSERT_PRODUCT", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProdName", Prod.Productname);
                cmd.Parameters.AddWithValue("@ProdDescription", Prod.ProductDescription);
                cmd.Parameters.AddWithValue("@ProdPrice", Prod.Productprice);
                cn.Open();
                no = cmd.ExecuteNonQuery();

            }
            catch (ProductException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }

    }
}
