﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Entities
{

    /// <summary>
    /// Class For Product and with getters and setters
    /// </summary>
    public class Product
    {
        public int ProductId { get; set; }

        public String Productname{ get; set; }

        public String ProductDescription { get; set; } 

        public double Productprice { get; set; }
    }
}
