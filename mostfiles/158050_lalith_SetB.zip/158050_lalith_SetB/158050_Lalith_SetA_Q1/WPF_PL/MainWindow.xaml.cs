﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using PM_BLL;
using PM_Entities;
using PM_Exceptions;

namespace WPF_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        ProductBLL bll = null;
        public MainWindow()
        {
            InitializeComponent();
            bll = new ProductBLL();
        }

        /// <summary>
        /// For Populating the DataGrid
        /// </summary>
        public void PopulateUI()
        {
            try
            {
                List<Product> prods = bll.GetAll();
                dgProducts.ItemsSource = prods;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
        }
        /// <summary>
        /// Validation of not null
        /// </summary>
        /// <returns></returns>

        public string ValidateUI()
        {
            StringBuilder sb = new StringBuilder();

            if ((txtProdName.Text).ToString() == string.Empty || (txtProdName.Text).ToString() == null)
                sb.Append("Product-Name is Mandatory" + Environment.NewLine);
            if ((txtDescription.Text).ToString() == string.Empty || (txtDescription.Text).ToString() == null)
                sb.Append("Description is Mandatory" + Environment.NewLine);
            if ((txtPrice.Text).ToString() == string.Empty || (txtPrice.Text).ToString() == null)
                sb.Append("Price is Mandatory" + Environment.NewLine);

            return sb.ToString();
           
        }
        /// <summary>
        /// Inserting data function on button Click 
        /// </summary>
       

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string message = null;

            if(message == null)
            {
                Product prod = new Product();
                prod.Productname = txtProdName.Text;
                prod.ProductDescription = txtDescription.Text;
                prod.Productprice = double.Parse(txtPrice.Text);

                try
                {
                    bll.Add(prod);
                    
                    MessageBox.Show("Inserted");
                    PopulateUI();
                }
                catch(ProductException ex1)
                {
                    MessageBox.Show(ex1.Message);
                }
                catch(Exception ex2)
                {
                    MessageBox.Show(ex2.Message);
                }
            }
            else
            {
                MessageBox.Show(message);
            }
        }

        /// <summary>
        /// For On Start of the Solution
        /// </summary>
       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
    }
}
