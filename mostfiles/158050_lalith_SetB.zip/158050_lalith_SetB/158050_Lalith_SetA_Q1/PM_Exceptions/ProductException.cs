﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Exceptions
{
    public class ProductException : Exception
    {
        public ProductException(String errmsg) : base(errmsg)
        {
                ///<summary>
                ///Constructor for Exception and passing it to the Base Class
                /// </summary>

        }
    }
}
