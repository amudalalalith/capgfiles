﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PM_DAL;
using PM_Entities;
using PM_Exceptions;
using System.Text.RegularExpressions;

namespace PM_BLL
{
    public class ProductBLL
    {
        /// <summary>
        /// Bll For all Logic Fuctions and Validations
        /// </summary>
        ProductDAL dal = null;

        public ProductBLL()
        {
            dal = new ProductDAL();
        }

        public static bool Validate(Product Prod)
        {
            bool validated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(Prod.Productname, "[A-Z][a-z]+"))
                {
                    message.Append("Product Name should start with capital alphabet and it should have alphabets only\n");
                    validated = false;
                }

                if(Prod.Productprice < 0)
                {
                    message.Append("Product price should not be lesas than 0\n");
                    validated = false;
                }

                if (validated == false)
                    throw new ProductException(message.ToString());
            }
            catch(ProductException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return validated;
        }

        public List<Product> GetAll()
        {
            List<Product> prod = null;
            try
            {
               prod = dal.SelectAll();
            }
            catch (ProductException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return prod;
        }

        public int Add(Product prod)
        {
            int no = 0;
            try
            {
                if (Validate(prod))
                    no = dal.Insert(prod);
            }
            catch (ProductException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

    }
}
