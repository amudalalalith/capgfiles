﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_CF_Demo1
{
    public class StudentCF_1580501
    {
        public int Id { get; set; }
        public string StudName { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public decimal FeePaid { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
    }
}
