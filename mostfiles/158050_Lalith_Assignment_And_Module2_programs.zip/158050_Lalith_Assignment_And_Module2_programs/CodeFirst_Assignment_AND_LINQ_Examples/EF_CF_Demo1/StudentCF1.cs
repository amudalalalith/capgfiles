﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_CF_Demo1
{
   public class StudentCF1 : DbContext
    {
        public StudentCF1() : base("name=cn1")
        {
                
        }

        public virtual DbSet<StudentCF_1580501> StudentCFs { get; set; }
    }
}
