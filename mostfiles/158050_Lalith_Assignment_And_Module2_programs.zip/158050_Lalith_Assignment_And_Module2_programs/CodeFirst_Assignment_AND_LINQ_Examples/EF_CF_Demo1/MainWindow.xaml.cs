﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EF_CF_Demo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentCF1 dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new StudentCF1();
        }

        public void PopulateUi()
        {
            List<StudentCF_1580501> studs = dbContext.StudentCFs.ToList();
            cmbRollNo.ItemsSource = dbContext.StudentCFs.ToList();
            cmbRollNo.DisplayMemberPath = "RollNo";
            dgStudents.ItemsSource = studs;
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            PopulateUi();
        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            PopulateUi();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            List<StudentCF_1580501> studs = dbContext.StudentCFs.ToList();
            int rollNo = int.Parse(cmbRollNo.Text);
            //Student stud = (from s in studs
            //               where s.RollNo == rollNo
            //               select s).Single();

            StudentCF_1580501 stud = studs.Find(s => s.Id == rollNo);
            if (stud != null)
            {
                stud.StudName = txtStudName.Text;
                stud.FeePaid = decimal.Parse(txtFeePaid.Text);
                stud.MobileNo = txtMobile.Text;

                string g = string.Empty;
                if ((bool)rbMale.IsChecked)
                {
                    g = rbMale.Content.ToString();
                }
                else if ((bool)rbFeMale.IsChecked)
                {
                    g = rbFeMale.Content.ToString();
                }
                stud.Gender = g;
                stud.Email = txtEmail.Text;
                stud.DOB = (DateTime)dpDob.SelectedDate;
                dbContext.SaveChanges();
                MessageBox.Show("Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            List<StudentCF_1580501> studs = dbContext.StudentCFs.ToList();
            int rollNo = int.Parse(cmbRollNo.Text);
            //Student stud = (from s in studs
            //               where s.RollNo == rollNo
            //               select s).Single();

            StudentCF_1580501 stud = studs.Find(s => s.Id == rollNo);

            dbContext.StudentCFs.Remove(stud);

            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            StudentCF_1580501 stud = new StudentCF_1580501();
            stud.StudName = txtStudName.Text;
            stud.FeePaid = decimal.Parse(txtFeePaid.Text);
            stud.MobileNo = txtMobile.Text;

            string g = string.Empty;
            if ((bool)rbMale.IsChecked)
            {
                g = rbMale.Content.ToString();
            }
            else if ((bool)rbFeMale.IsChecked)
            {
                g = rbFeMale.Content.ToString();
            }
            stud.Gender = g;
            stud.Email = txtEmail.Text;
            stud.DOB = (DateTime)dpDob.SelectedDate;
            dbContext.StudentCFs.Add(stud);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
        }
    }
}
