﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EF_Demo1
{
    /// <summary>
    /// Interaction logic for IUD_EFDF_Demo.xaml
    /// </summary>
    public partial class IUD_EFDF_Demo : Window
    {
        Entities dbContext = null;
        public IUD_EFDF_Demo()
        {
            InitializeComponent();
            dbContext = new Entities();
        }
        public void PopulateUi()
        {
            List<Student> studs = dbContext.Students.ToList();
            cmbRollNo.ItemsSource = dbContext.Students.ToList();
            cmbRollNo.DisplayMemberPath = "RollNo";
            dgStudents.ItemsSource = studs;
        }
        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            PopulateUi();

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            List<Student> studs = dbContext.Students.ToList();
            int rollNo = int.Parse(cmbRollNo.Text);
            //Student stud = (from s in studs
            //               where s.RollNo == rollNo
            //               select s).Single();

            Student stud = studs.Find(s => s.RollNo == rollNo);
            if (stud != null)
            {
                stud.StudName = txtStudName.Text;
                stud.FeePaid = decimal.Parse(txtFeePaid.Text);
                stud.MobileNo = txtMobile.Text;

                string g = string.Empty;
                if ((bool)rbMale.IsChecked)
                {
                    g = rbMale.Content.ToString();
                }
                else if ((bool)rbFeMale.IsChecked)
                {
                    g = rbFeMale.Content.ToString();
                }
                stud.Gender = g;
                stud.Email = txtEmail.Text;
                stud.DOB = dpDob.SelectedDate;
                dbContext.SaveChanges();
                MessageBox.Show("Updated");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            List<Student> studs = dbContext.Students.ToList();
            int rollNo = int.Parse(cmbRollNo.Text);
            //Student stud = (from s in studs
            //               where s.RollNo == rollNo
            //               select s).Single();

            Student stud = studs.Find(s => s.RollNo == rollNo);

            dbContext.Students.Remove(stud);

            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
            
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Student stud = new Student();
            stud.StudName = txtStudName.Text;
            stud.FeePaid = decimal.Parse(txtFeePaid.Text);
            stud.MobileNo = txtMobile.Text;

            string g = string.Empty;
            if((bool)rbMale.IsChecked)
            {
                g = rbMale.Content.ToString();
            }
            else if ((bool)rbFeMale.IsChecked)
            {
                g = rbFeMale.Content.ToString();
            }
            stud.Gender = g;
            stud.Email = txtEmail.Text;
            stud.DOB = dpDob.SelectedDate;
            dbContext.Students.Add(stud);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");



        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUi();
        }
    }
}
