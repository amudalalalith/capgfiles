﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Examples
{
    public class Student
    {
        public int RollNo { get; set; }

        public String StudName { get; set; }

        public List<int> Marks = new List<int>();

        public double FeePaid { get; set; }

        public int Standard { get; set; } //1 - 4

        public static List<Student> GetAllStudents()
        {
            List<Student> studs = new List<Student>();
            Student s1 = new Student() { RollNo = 101, StudName = "Manish", FeePaid = 3400, Standard = 1, Marks = { 25, 35, 10, 45 } };
            Student s2 = new Student() { RollNo = 112, StudName = "Lalith", FeePaid = 5400, Standard = 1, Marks = { 45, 32, 10, 35 } };
            Student s3 = new Student() { RollNo = 123, StudName = "Gautam", FeePaid = 3400, Standard = 3, Marks = { 44, 45, 15, 45 } };
            Student s4 = new Student() { RollNo = 134, StudName = "vikram", FeePaid = 2340, Standard = 3, Marks = { 23, 45, 14, 45 } };
            studs.Add(s1);
            studs.Add(s2);
            studs.Add(s3);
            studs.Add(s4);

            return studs;
        }

        public override string ToString()
        {

            return RollNo+","+StudName+","+FeePaid+","+Standard;
        }




    }
}
