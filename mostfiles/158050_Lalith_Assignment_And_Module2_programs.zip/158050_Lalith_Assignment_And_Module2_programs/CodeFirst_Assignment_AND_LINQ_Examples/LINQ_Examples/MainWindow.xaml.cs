﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LINQ_Examples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string[] lines = new string[] {
              "This is our ADO.NET Training",
              "We are in CHennai NOw",
              "How are you doing Today",
                "I'm happy to hear that you are also in the same Program",
              "Thanks Everyone gdkjf"
            };
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSample1_Click(object sender, RoutedEventArgs e)
        {
           
            var res1 = from line in lines
                       where line.StartsWith("T")
                       select line;
            

            foreach (var r in res1)
            {
                MessageBox.Show(r);
            }
        }

        private void btnSample2_Click(object sender, RoutedEventArgs e)
        {
            var res1 = from line in lines
                       from word in line.Split(' ')
                       select word;
            MessageBox.Show(res1.Count().ToString());
        }

        private void btnSample3_Click(object sender, RoutedEventArgs e)
        {
            //var res1 = (from l in lines
            //                      where l.StartsWith("How")
            //                      select l).Single().Split(' ');
            //foreach (var w in res1)
            //{
            //    MessageBox.Show(w);
            //}


            //var res1 = from w in ((from l in lines
            //            where l.StartsWith("How")
            //            select l).Single().Split(' '))
            //            orderby w descending
            //            select w;
            //foreach (var w in res1)
            //{
            //    MessageBox.Show(w);
            //}


            var res1 = from w in ((from l in lines
                                   where l.StartsWith("How")
                                   select l).Single().Split(' '))
                       orderby w.Length descending
                       select w;


            foreach (var w in res1.Reverse())
            {
                MessageBox.Show(w);
            }

            //var res1 = lines.Where(l => l.StartsWith("How")).Single();
            //foreach(var item in res1.Split(' '))
            //{
            //    MessageBox.Show(item);
            //}
        }

        private void btnSample4_Click(object sender, RoutedEventArgs e)
        {
            List<Student> stud = Student.GetAllStudents();
            //1. Display names of all students from STD 1
            //var res1 = (from s in stud
            //            where s.Standard == 1
            //            select s.StudName
            //           );

            //foreach(var item in res1)
            //{
            //    MessageBox.Show(item);
            //}

            //2. Display Student details by desending order of the names of Students 
            //var res2 = (from s in stud
            //            orderby s.StudName descending
            //            select s.StudName
            //            );

            //foreach (var item in res2)
            //{
            //    MessageBox.Show(item);
            //}

            //3. Display Total Marks of all subjects from STD-3 students
           /* var res3 = from mrks in (from s in stud
                                  where s.Standard == 3
                                  select s.Marks)
                                  from m in mrks 
                                  select m;
            MessageBox.Show(res3.Sum().ToString());
            */

            //4. Group the students according to the STD

            /*var grps = from s in stud
                       group s by s.Standard;
            foreach(var g in grps)
            {
                MessageBox.Show("Students from STD-" + g.Key.ToString());
                foreach (var s in g)
                {
                    MessageBox.Show(s.ToString());
                }
            }
            */

            //5. Display Student by order of FeePaid then by Name
            /*
            var res5 = from s in stud
                       orderby s.FeePaid, s.StudName
                       select s;
            foreach (var item in res5)
            {
                MessageBox.Show(item.ToString());
            }
            */


            //6. Display Student-Name, FeePaid & STD for students those who paid Fee in range of 2000 to 3500

            var res6 = from s in stud
                       where s.FeePaid >= 2000 & s.FeePaid <= 3500
                       select new { SN = s.StudName, s.FeePaid, s.Standard }; // returning ananymous object using new
            foreach (var item in res6)//item is of ananymouys type
            {
                MessageBox.Show(item.SN + ", " + item.FeePaid + ", " + item.Standard);
            }

        }
    }
}
