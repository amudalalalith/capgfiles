﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
namespace WpfAssignment
{
    class Student : DependencyObject
    {


        public int StudentId
        {
            get { return (int)GetValue(StudentIdProperty); }
            set { SetValue(StudentIdProperty, value); }
        }

        // Using a DependencyProperty as the backing store for StudentId.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty StudentIdProperty =
            DependencyProperty.Register("StudentId", typeof(int), typeof(Student), new PropertyMetadata(0));


    }
}
