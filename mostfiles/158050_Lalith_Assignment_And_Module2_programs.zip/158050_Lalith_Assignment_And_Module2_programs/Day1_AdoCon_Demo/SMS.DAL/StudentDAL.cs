﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Exceptions;

using SMS_Entities;

using System.Data.SqlClient;
using System.Configuration;

namespace SMS.DAL
{
    public class StudentDAL
    {
        //SelectAll
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        public StudentDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public List<Student> SelectAll()
        {
            List<Student> Studs = new List<Student>();
            try
            {
                //cmd = new SqlCommand("select * from Lalith.Student", cn);

                cmd = new SqlCommand("Lalith.USP_SelectAll_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cn.Open();
                dr = cmd.ExecuteReader();
                
                while(dr.Read())
                {
                    Student s = new Student();
                    s.RollNo =  Convert.ToInt32(dr[0]);
                    s.StudName = dr[1].ToString();
                    s.Gender = dr[2].ToString();
                    s.DOB = Convert.ToDateTime(dr[3]);
                    s.FeePaid = Convert.ToDouble(dr[4]);
                    s.MobileNo = dr[5].ToString();
                    s.Email = dr[6].ToString();

                    Studs.Add(s);
                }

            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return Studs;
        }


        public int Insert(Student stud)
        {

            int no = 0;
            try
            {
                //cmd = new SqlCommand("insert into Lalith.Student(StudName, Gender, DOB, FeePaid, MobileNo, Email) values('" + stud.StudName + "', '" + stud.Gender + "', '" + stud.DOB + "', " + stud.FeePaid + ", '" + stud.MobileNo + "', '" + stud.Email + "')", cn);

                cmd = new SqlCommand("Lalith.USP_Insert_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudName", stud.StudName);
                cmd.Parameters.AddWithValue("@Gender", stud.Gender);
                cmd.Parameters.AddWithValue("@DOB", stud.DOB);
                cmd.Parameters.AddWithValue("@FeePaid", stud.FeePaid);
                cmd.Parameters.AddWithValue("@MobileNo", stud.MobileNo);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cn.Open();
                no = cmd.ExecuteNonQuery();
                
            }
            catch(StudentException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;

        }


        public int Update(Student stud)
        {
            int no = 0;
            try
            {
                //cmd = new SqlCommand("update Lalith.Student set StudName='"+stud.StudName+"', Gender = '"+stud.Gender+"',DOB = '"+stud.DOB+"',FeePaid = "+stud.FeePaid+",MobileNo = '"+stud.MobileNo+"',Email = '"+stud.Email+"' where RollNo = "+stud.RollNo, cn);

                cmd = new SqlCommand("Lalith.USP_Update_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RollNo", stud.RollNo);
                cmd.Parameters.AddWithValue("@StudName", stud.StudName);
                cmd.Parameters.AddWithValue("@Gender", stud.Gender);
                cmd.Parameters.AddWithValue("@DOB", stud.DOB);
                cmd.Parameters.AddWithValue("@FeePaid", stud.FeePaid);
                cmd.Parameters.AddWithValue("@MobileNo", stud.MobileNo);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cn.Open();
                no = cmd.ExecuteNonQuery();

            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;

        }


        public int Delete(int RollNo)
        {
            int no = 0;
            try
            {
                // cmd = new SqlCommand("delete Lalith.Student where RollNo = " + RollNo, cn);

                cmd = new SqlCommand("Lalith.USP_Delete_Student", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RollNo", RollNo);
                cn.Open();
                no = cmd.ExecuteNonQuery();

            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;

        }



    }
}
