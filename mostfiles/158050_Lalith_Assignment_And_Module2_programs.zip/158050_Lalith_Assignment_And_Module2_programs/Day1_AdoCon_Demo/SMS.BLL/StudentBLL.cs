﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entities;
using SMS.DAL;
using SMS.Exceptions;

namespace SMS.BLL
{
    public class StudentBLL
    {
        StudentDAL dal = null;

        public StudentBLL()
        {
            dal = new StudentDAL();
        }

        public List<Student> GetAll()
        {
            List<Student> studs = null;
            try
            {
                studs = dal.SelectAll();
            }
            catch(StudentException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
            return studs;
        }

        public int Add(Student stud)
        {

            int no = 0;
            try
            {
              no= dal.Insert(stud);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

        public int Edit(Student stud)
        {
            int no = 0;
            try
            {
               no = dal.Update(stud);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

        public int Remove(int rollNo)
        {
            int no = 0;
            try
            {
               no = dal.Delete(rollNo);
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            return no;
        }

    }
}
