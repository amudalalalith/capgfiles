﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.BLL;
using SMS_Entities;
namespace WPF.PL
{
    /// <summary>
    /// Interaction logic for ListView.xaml
    /// </summary>
    public partial class ListView : Window
    {
        StudentBLL details = null;
        //Student stu = new Student();
        public ListView()
        {
            InitializeComponent();
          details = new StudentBLL();
            
        }

        private void studentList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            List<Student> stud = details.GetAll().ToList();
            //studentList.TextInput =
        }
        //  = 
    }
}
