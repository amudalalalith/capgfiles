﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS.BLL;
using SMS_Entities;
namespace WPF.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBLL bll = null;
        
        public MainWindow()
        {
            InitializeComponent();
            bll = new StudentBLL();
        }

        public void populateUI()
        {
            try
            {
                //dgStudents.ItemsSource = bll.GetAll();
                //cmbStudName.ItemsSource = bll.GetAll();

                // similar

                List<Student> studs = bll.GetAll();
                dgStudents.ItemsSource = studs;
                cmbStudName.ItemsSource = studs;
                cmbStudName.DisplayMemberPath = "StudName";

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
         }



        private void buttonSubmit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            populateUI();

        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            populateUI();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            
            Student s = new Student();
            s.StudName = cmbStudName.Text;
           // s.Gender = "Male";
            s.DOB = (DateTime)dpDob.SelectedDate;
            s.FeePaid = double.Parse(txtFeePaid.Text);
            s.MobileNo = txtMobile.Text;
            s.Email = txtEmail.Text;
            string g = string.Empty;
            if ((bool)rbMale.IsChecked)
            {
                g = rbMale.Content.ToString();
            }
            else if ((bool)rbFeMale.IsChecked)
            {
                g = rbFeMale.Content.ToString();
            }
            s.Gender = g;
            bll.Add(s);
            MessageBox.Show("Inserted");
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            
            Student s = (Student)cmbStudName.SelectedItem;
            //s.RollNo = int.Parse(cmbId.Text); //No need of Roll No
            s.StudName = cmbStudName.Text;
            //s.Gender = "Male";
            s.DOB = (DateTime)dpDob.SelectedDate;
            s.FeePaid = double.Parse(txtFeePaid.Text);
            s.MobileNo = txtMobile.Text;
            s.Email = txtEmail.Text;

            //Student s = new Student();
            //s.RollNo = int.Parse(cmbId.Text);
            //s.StudName = cmbStudName.Text;
            ////s.Gender = "Male";
            //s.DOB = (DateTime)dpDob.SelectedDate;
            //s.FeePaid = double.Parse(txtFeePaid.Text);
            //s.MobileNo = txtMobile.Text;
            //s.Email = txtEmail.Text;

            string g = string.Empty;
            if((bool)rbMale.IsChecked)
            {
                g = rbMale.Content.ToString();
            }
            else if ((bool)rbFeMale.IsChecked)
            {
                g = rbFeMale.Content.ToString();
            }
            s.Gender = g;
            bll.Edit(s);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            //int rollNo = int.Parse(cmbId.Text);
            try
            {
                Student s = (Student)cmbStudName.SelectedItem;
                bll.Remove(s.RollNo);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
