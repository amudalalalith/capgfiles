﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistrationForm
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void imgcal_Click(object sender, EventArgs e)
        {
            CalendarDialog cal = new CalendarDialog();
            cal.StartPosition = FormStartPosition.CenterScreen;
            if (cal.ShowDialog() == DialogResult.OK)
                txtbirthdate.Text = cal.DateSelection.SelectionStart.
                ToString("dd-MMM - yyyy");
        }
    }
}
