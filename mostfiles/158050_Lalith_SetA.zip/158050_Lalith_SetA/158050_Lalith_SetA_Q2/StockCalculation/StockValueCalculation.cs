﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockCalculation
{
    /// <summary>
    /// Delegate Declaration
    /// </summary>
    /// <param name="unitPrice"></param>
    /// <param name="unitInStock"></param>
    /// <returns></returns>
    public delegate double StockHandler(double unitPrice, int unitInStock);
     class StockValueCalculation
    {
        static void Main(string[] args)
        {

            ///<summary>
            ///Lambda Function in ananoumous Decleration of delegate 
            /// </summary>
            StockHandler stockValue = (x, y) => { return x * y; };

            //Console.WriteLine("Enter No of Units in Stock : ");
            //int units = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter unit Price : ");
            //double price = double.Parse(Console.ReadLine());

            ///<system>
            ///using or calling Delegate and Ananamous Lambda function
            /// </system>
            double value = stockValue(20, 30);
            Console.WriteLine("Stock value is : "+value);
            Console.ReadKey();
        }
    }
}
