﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABC_Entities;
using ABC_Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ABC_DAL
{
    public class InvoiceOperations
    {
        public static List<Invoice> invList = new List<Invoice>();

        /// <summary>
        /// Add Function for adding the values to the List
        /// </summary>
        /// <param name="newinvoice"></param>
        /// <returns></returns>
        public bool AddInvoiceDAL(Invoice newinvoice)
        {
            bool invoiceAdded = false;
            try
            {
                invList.Add(newinvoice);
                invoiceAdded = true;
            }
            catch(InvoiceException)
            {
                throw;
            }
            return invoiceAdded;
        }

        /// <summary>
        /// Displaying from the List passing it to the BLL
        /// </summary>
        /// <returns></returns>
        public List<Invoice> DiaplayInvoiceDAL()
        {
            return invList;
        }

        /// <summary>
        /// Method for Deleting the list object
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        public bool DeleteInvoiceDAL(int invoiceId)
        {
            bool isInvoiceDeleted = false;
            Invoice invToDelete = new Invoice();
            try
            {
                invToDelete = invList.Find(inv => inv.InvoiceNo == invoiceId);
                invList.Remove(invToDelete);
                isInvoiceDeleted = true;
            }
            catch(InvoiceException)
            { throw; }
            return isInvoiceDeleted;
        }

        /// <summary>
        /// Method for Serialization
        /// </summary>
        public static void SerializeInvoiceDAL()
        {
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("SampleInvoice.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter binFormatter = new BinaryFormatter();
                binFormatter.Serialize(fStream, invList);
            }
            catch(IOException)
            { throw; }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }

        }
        /// <summary>
        /// Method for Deserialization in DAL
        /// </summary>
        /// <returns></returns>
        public static List<Invoice> DeserializeInvoiceDAL()
        {
            List<Invoice> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("SampleInvoice.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binFormatter = new BinaryFormatter();
                deserializedData = (List<Invoice>)binFormatter.Deserialize(fStream);
            }
            catch(IOException)
            {
                throw;
            }
            catch(Exception)
            { throw; }
            finally
            { fStream.Close(); }
            return deserializedData;
        }

    }
}
