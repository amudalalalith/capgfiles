﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Entities
{
    [Serializable]
    public class Invoice
    {
        /// <summary>
        /// Properties of Invoice
        /// </summary>
        public int InvoiceNo { get; set; }
        public DateTime DOI { get; set; }
        public string CustomerName { get; set; }
        public string ProductName { get; set; }
        //public ProductType ProductName { get; set; } //use with enum
        public long Amount { get; set; }
    }
    /// <summary>
    /// Enum Decleration
    /// </summary>
    public enum ProductType
    {
        Food, Groceries, Electronic, Games
    }
}
