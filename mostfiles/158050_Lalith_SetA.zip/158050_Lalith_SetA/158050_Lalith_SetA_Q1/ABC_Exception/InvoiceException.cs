﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC_Exception
{
    public class InvoiceException : Exception
    {
        /// <summary>
        /// default constructor
        /// </summary>
        public InvoiceException() : base()
        {

        }
        /// <summary>
        /// Constructor passing with parameters to base 
        /// </summary>
        /// <param name="errmsg"></param>
        public InvoiceException(string errmsg) : base(errmsg)
        {
                
        }
    }
}
