﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ABC_DAL;
using ABC_Entities;
using ABC_Exception;
using System.IO;

namespace ABC_BLL
{
    public class InvoiceValidations
    {
        InvoiceOperations operationsObj;
        static List<Invoice> invoList = new List<Invoice>();

        /// <summary>
        /// Method for Validating the Details of Invoice
        /// </summary>
        /// <param name="newInvoice"></param>
        /// <returns></returns>
        public bool ValidateInvoice(Invoice newInvoice)
        {
            bool isValidateInvoice = true;
            StringBuilder sbABCError = new StringBuilder();
            if(newInvoice.InvoiceNo.ToString().Equals(string.Empty))
            {
                isValidateInvoice = false;
                sbABCError.Append("Invoice No cannot be Empty" + Environment.NewLine);
            }
            if (newInvoice.InvoiceNo.ToString().Length != 6)
            {
                isValidateInvoice = false;
                sbABCError.Append("Invoice must not be less tha 6 digits" + Environment.NewLine);
            }
            if (newInvoice.DOI < DateTime.Now)
            {
                isValidateInvoice = false;
                sbABCError.Append("Invoice Date Cannot be Less than today's Date" + Environment.NewLine);
            }
            if (newInvoice.CustomerName.Equals(string.Empty))
            {
                isValidateInvoice = false;
                sbABCError.Append("Name cannot be Empty" + Environment.NewLine);
            }
            if(!(newInvoice.ProductName.Equals("Food Products") || newInvoice.ProductName.Equals("Groceries") || newInvoice.ProductName.Equals("Electronic items") || newInvoice.ProductName.Equals("Games") ))
            {
                isValidateInvoice = false;
                sbABCError.Append("Product Name Not Satisfied" + Environment.NewLine);
            }
            if(!isValidateInvoice)
            { throw new InvoiceException(sbABCError.ToString()); }
            return isValidateInvoice;
        }

        /// <summary>
        /// Method for conducting validation and passing it to the DAL
        /// </summary>
        /// <param name="newInvoice"></param>
        /// <returns></returns>
        public bool AddInvoiceBLL(Invoice newInvoice)
        {
            bool isInvoiceAdded = false;
            try
            {
                operationsObj = new InvoiceOperations();
                if (ValidateInvoice(newInvoice))
                    isInvoiceAdded = operationsObj.AddInvoiceDAL(newInvoice);
                else
                    throw new InvoiceException("Validation Failed !! Invoice record cannot be added");
            }
            catch(InvoiceException)
            { throw; }
            return isInvoiceAdded;

        }

        /// <summary>
        /// Method for Displaying getting values from BLL and returning to PL
        /// </summary>
        /// <returns></returns>
        public List<Invoice> DisplayInvoiceBLL()
        {
            try
            {
                operationsObj = new InvoiceOperations();
                invoList = operationsObj.DiaplayInvoiceDAL();
                if(invoList.Count <= 0)
                {
                    throw new InvoiceException("No Records Found");
                }
            }
            catch(InvoiceException ex)
            { throw ex; }
            return invoList;
        }

        /// <summary>
        /// Method for Deleting in BLL
        /// </summary>
        /// <param name="InvoiceNo"></param>
        /// <returns></returns>
        public bool DeleteInvoiceBLL(int InvoiceNo)
        {
            bool isDeleted = false;
            try
            {
                operationsObj = new InvoiceOperations();
                isDeleted = operationsObj.DeleteInvoiceDAL(InvoiceNo);
                if (!isDeleted) throw new InvoiceException("Employee Could not be found");
            }
            catch(InvoiceException ix) { throw ix; }
            return isDeleted;
        }

        /// <summary>
        /// Method for Serialization in BLL
        /// </summary>
        public void SerializeInvoiceBLL()
        {
            try
            {
                InvoiceOperations.SerializeInvoiceDAL();
            }
            catch(IOException ix) { throw ix; }
            catch(Exception ix) { throw ix; }
        }

        /// <summary>
        /// Method for DeSerialization in BLL 
        /// </summary>
        /// <returns></returns>
        public List<Invoice> DeserializeInvoiceBLL()
        {
            List<Invoice> invList = null;
            try
            {
                invList = InvoiceOperations.DeserializeInvoiceDAL();
                if (invList.Count <= 0) throw new InvoiceException("No records Found");
            }
            catch(InvoiceException ix) { throw ix; }
            catch(IOException ix) { throw ix; }
            catch(Exception ix) { throw ix; }
            return invList;
        }



    }
}
