﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ABC_BLL;
using ABC_Entities;
using ABC_Exception;
using System.IO;

namespace ABC_PL
{
    class InvoicePresentation
    {
        static InvoiceValidations objValidation;
        /// <summary>
        /// Method In PL for Adding Details
        /// </summary>
        public static void AddInvoice()
        {
            try
            {
                objValidation = new InvoiceValidations();
                Invoice invNew = new Invoice();

                Console.WriteLine("Enter Invoice NO : ");
                invNew.InvoiceNo = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter Invoice Date : ");
                invNew.DOI = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Customer Name ");
                invNew.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Product Name :  ");
                invNew.ProductName = Console.ReadLine();
                //invNew.ProductName = (ProductType)Enum.Parse(typeof(ProductType), Console.ReadLine());
                Console.WriteLine("Enter Amount : ");
                invNew.Amount = long.Parse(Console.ReadLine());

                if(objValidation.AddInvoiceBLL(invNew))
                    Console.WriteLine("Invoice Added Sucessfully");
                
            }
            catch(InvoiceException ix)
            { throw ix; }
            catch(FormatException ix)
            { throw ix; }
            catch(Exception ix)
            { throw ix; }
        }

        /// <summary>
        /// Method For Displaying In PL
        /// </summary>
        public static void DisplayInvoice()
        {
            try
            {
                objValidation = new InvoiceValidations();
                List<Invoice> invList = objValidation.DisplayInvoiceBLL();
                Console.WriteLine("List of Employees");

                foreach(Invoice invItem in invList)
                {
                    Console.WriteLine(" Invoice No : {0}", invItem.InvoiceNo.ToString());
                    Console.WriteLine(" Invoice Date : {0}", invItem.DOI.ToShortDateString());
                    Console.WriteLine(" Customer Name : {0}", invItem.CustomerName);
                    Console.WriteLine(" Product Name : {0}", invItem.ProductName);
                    //Console.WriteLine(" Product Name : {0}", invItem.ProductName.ToString());
                    Console.WriteLine(" Amount : {0}", invItem.Amount.ToString());

                }
            }
            catch(InvoiceException ix)
            { Console.WriteLine(ix.Message); }
            catch(Exception ix)
            { Console.WriteLine(ix.Message); }
        }

        /// <summary>
        /// Method for Serialization In PL
        /// </summary>
        private static void SerializeInvoice()
        {
            try
            {
                objValidation.SerializeInvoiceBLL();
                Console.WriteLine("Invoice Record Stored in File");
            }
            catch (InvoiceException ix) { Console.WriteLine(ix.Message); }
            catch (IOException ix) { Console.WriteLine(ix.Message); }
            catch (Exception ix) { Console.WriteLine(ix.Message); }
        }

        /// <summary>
        /// Method for Deserialization
        /// </summary>
        private static void DeserializeInvoice()
        {
            try
            {
                List<Invoice> iList = objValidation.DeserializeInvoiceBLL();
                Console.WriteLine("Records From File: ");
                foreach(Invoice inv in iList)
                {
                    Console.WriteLine(" Invoice No : {0}", inv.InvoiceNo.ToString());
                    Console.WriteLine(" Invoice Date : {0}", inv.DOI.ToShortDateString());
                    Console.WriteLine(" Customer Name : {0}", inv.CustomerName);
                    Console.WriteLine(" Product Name : {0}", inv.ProductName);
                    
                    Console.WriteLine(" Amount : {0}", inv.Amount);
                }
            }
            catch (InvoiceException ix) { Console.WriteLine(ix.Message); }
            catch (IOException ix) { Console.WriteLine(ix.Message); }
            catch (Exception ix) { Console.WriteLine(ix.Message); }
        }

        /// <summary>
        /// Method For Deleting by passing value to BLL
        /// </summary>
        private static void DeleteInvoice()
        {
            try
            {
                Console.WriteLine("Enter Invoice No to be Deleted:");
                int InvNo = Int32.Parse(Console.ReadLine());
                bool isDeleted = objValidation.DeleteInvoiceBLL(InvNo);
                if (isDeleted) Console.WriteLine("Record Deleted!! ");
            }
            catch (InvoiceException ix) { Console.WriteLine(ix.Message); }
            catch (Exception ix) { Console.WriteLine(ix.Message); }
        }

        /// <summary>
        /// Print Method
        /// </summary>
        public static void PrintMenu()
        {
            Console.WriteLine("============================================");
            Console.WriteLine("ABC Invoice System");
            Console.WriteLine("Press 1 To Add New Invoice");
            Console.WriteLine("Press 2 To Display All Invoice");
            Console.WriteLine("Press 3 To Delete Invoice");
            Console.WriteLine("Press 4 To Store Data in File");
            Console.WriteLine("Press 5 Display Data from File");
            Console.WriteLine("Press 6 To Exit");
           
        }

        static void Main(string[] args)
        {

            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice:");
                bool chkChoice;
                chkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input "); }
                switch (choice)
                {
                    case 1:
                        AddInvoice();
                        break;
                    case 2:
                        DisplayInvoice();
                        break;
                    case 3:
                        DeleteInvoice();
                        break;
                    case 4:
                        SerializeInvoice();
                        break;
                    case 5:
                        DeserializeInvoice();
                        break;
                    case 6:
                        break;
                    default:
                        Console.WriteLine("invalid Choice");
                        break;
                }
            } while (choice != 6);
            Console.ReadKey();



        }
    }
}
