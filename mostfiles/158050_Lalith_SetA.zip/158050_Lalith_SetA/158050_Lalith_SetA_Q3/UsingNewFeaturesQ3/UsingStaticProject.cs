﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static UsingNewFeaturesQ3.UsingStaticDeclaration;
namespace UsingNewFeaturesQ3
{
    class UsingStaticProject
    {
       
        static void Main(string[] args)
        {
            PrintProject();
            Console.ReadKey();
        }
    }
    /// <summary>
    /// Declerartion and Implementation of using static
    /// </summary>
    static class UsingStaticDeclaration
    {
        /// <summary>
        /// Property Initializers
        /// </summary>
        public static int ProjectId { get; set; } = 1234;
        public static string ProjectName { get; set; } = "Bank Of Chennai";
        /// <summary>
        /// String Interpolation
        /// </summary>
        public static void PrintProject() => WriteLine($"PId:{ProjectId} PName:{ProjectName}");
    }
}
